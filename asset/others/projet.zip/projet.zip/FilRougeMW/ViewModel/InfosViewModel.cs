﻿using FilRougeMW.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace FilRougeMW.ViewModel
{
    class InfosViewModel : ObservableObject, INotifyPropertyChanged
    {

       
        private static int compteurInfos;
        private int compteurDePage ;
        private static bool verificationPageConnexion;


        public static int CompteurInfos { get => compteurInfos; set => compteurInfos = value; }
        public static bool VerificationPageConnexion { get => verificationPageConnexion; set => verificationPageConnexion = value; }
        public int CompteurDePage { get => compteurDePage; set => compteurDePage = value; }


        public ICommand CommandQuitter { get; private set; }
        public ICommand CommandOuvrirInfos { get; private set; }
        



        public InfosViewModel()
        {
            
            PrincipalViewModel.CompteurInfos++;
            CommandQuitter = new RelayCommandSP(Quitter);
            CommandOuvrirInfos = new RelayCommandSP(OuvrirInfos);
            ChargerTexteInfos();

        }



        private void ChargerTexteInfos()
        {
            if (verificationPageConnexion == true)
            {
                TexteConnexion();
            }
            else
            {
                compteurInfos = PrincipalViewModel.CompteurInfos;

                if (compteurInfos == 3)
                {
                    TexteModifier();

                }
                else if ( compteurInfos == 5)
                {
                    TexteFinal();
                } 
                else
                {
                    TexteNormal();
                }
                

            }
  

        }

        private void TexteNormal()
        {

            Texteinfos = "Cette Application a été faite par Mohammed Et Matthieu dans le cadre d'une formation";
            Texteinfos += "\r \n";
            Texteinfos += "Celle-ci est codé en c# ";
            Texteinfos += " \r \n"; 
            Texteinfos += "C'est le fil rouge qui nous accompagnera tout au long de la formation Développeur Logiciel à L'AFPA de Roubaix  section 2018/2019";
            
        }
        private void TexteConnexion()
        {
            Texteinfos = "SECRET DEFENSE SORRY :')";
            MessageBox.Show( "Désolé mais comme tu n'es pas connecté , je peux pas te laisser d'infos :'( ");
            

        }
        private void TexteModifier()
        {
            TexteNormal();
            MessageBox.Show("Tu as pas marre de lire les infos ??? ");
            
        }
        private void TexteFinal()
        {
            MessageBox.Show("Désolé mais je n'ai plus vraiment de salive je suis désolé :c \n à la prochaine :D");
            Environment.Exit(0);
            
        } 
        private void Quitter()
        {
            
            App.Current.Windows[PrincipalViewModel.CompteurPage].Close();
            PrincipalViewModel.CompteurPage--;
        }

        private void OuvrirInfos()
        {
            PrincipalViewModel.CompteurPage ++;
            Infos fenetre = new Infos();
            fenetre.Show();
        }



        private string _texteinfos;
        public string Texteinfos
        {
            get { return _texteinfos; }
            set
            {
                _texteinfos = value;
                RaisePropertyChanged("Texteinfos");
            }
        }

       
        
    }
}
