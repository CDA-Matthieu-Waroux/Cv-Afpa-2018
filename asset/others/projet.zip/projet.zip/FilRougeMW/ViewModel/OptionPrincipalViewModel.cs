﻿using FilRougeMW.Helpers;
using FilRougeMW.Model.Service;
using FilRougeMW.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace FilRougeMW.ViewModel
{
    class OptionPrincipalViewModel : ObservableObject, INotifyPropertyChanged
    {

        public ICommand CommandQuitter { get; private set; }
        public ICommand CommandOuvrirInfos { get; private set; }
       
        

        private static List<string> listeoptions;


        public static List<string> ListeOptions
        {
            get
            {
                return Listeoptions;
            }
        }



        public static List<string> Listeoptions { get => listeoptions; set => listeoptions = value; }

        public OptionPrincipalViewModel ()
        {
            CommandQuitter = new RelayCommandSP(Quitter);
            CommandOuvrirInfos = new RelayCommandSP(OuvrirInfos);
            
            listeoptions = ServiceOptions.ChargeeDonneeOptionsByID(PrincipalViewModel.Id);
           

            
        }
        
        

        private void Quitter()
        {
            Listeoptions.Clear();
            App.Current.Windows[1].Close();
        }


        private void OuvrirInfos()
        {
            InfosViewModel.VerificationPageConnexion = false;
            Infos fenetre = new Infos();
            fenetre.Show();
            PrincipalViewModel.CompteurPage = 2;
        }
    }
}
