﻿using FilRougeMW.Helpers;
using FilRougeMW.Model.Class;
using FilRougeMW.Model.Service;
using FilRougeMW.View;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace FilRougeMW.ViewModel
{
    class AjouterUtilisateurViewModel : ObservableObject , INotifyPropertyChanged
    {
        
        public ICommand CommandQuitter { get; private set; }        
        public ICommand CommandAjouter { get; private set; } 
        public ICommand CommandOuvrirInfos { get; private set; }
        

        private ObservableCollection<string> listenomutilisateur;
        private ObservableCollection<string> listecleemploye;
        private ObservableCollection<Utilisateur> listeUtilisateur;
        private ObservableCollection<string> listeCleEmployeUtilise = new ObservableCollection<string>();
        private string temporaire;

        public ObservableCollection<string> ListeNomutilisateur { get => listenomutilisateur; set => listenomutilisateur = value; }
        public ObservableCollection<string> Listecleemploye { get => listecleemploye; set => listecleemploye = value; }
        public string Temporaire { get => temporaire; set => temporaire = value; }
        public ObservableCollection<Utilisateur> ListeUtilisateur { get => listeUtilisateur; set => listeUtilisateur = value; }
        public ObservableCollection<string> ListeCleEmployeUtilise { get => listeCleEmployeUtilise; set => listeCleEmployeUtilise = value; }



        public AjouterUtilisateurViewModel()
        {
            CommandQuitter = new RelayCommandSP(Quitter);            
            CommandAjouter = new RelayCommandSP(Ajouter);
            CommandOuvrirInfos = new RelayCommandSP(OuvrirInfos);
            listenomutilisateur = ServiceUtilisateur.ChargeeDonnee();
            listecleemploye = ServiceEmploye.ObtenirClefEmploye();
            ListeUtilisateur = ServiceUtilisateur.ObtenirUtilisateur();
            

        }

        public ObservableCollection<string> ListeCleEmploye
        {
            get { return Listecleemploye; }
        }
        private string _nomutilisateur ;
        public string NomUtilisateur
        {
            get { return _nomutilisateur; }
            set
            {
                _nomutilisateur = value;
                RaisePropertyChanged("Utilisateur");
            }
        }

        private string _motDePasse ;
        public string MotDePasse
        {
            get { return _motDePasse; }
            set
            {
                _motDePasse = value;
                RaisePropertyChanged("MotDePasse");
            }
        }
        private string _cleEmploye ;
            public string CleEmploye
        {
            get { return _cleEmploye; }
            set
            {
                _cleEmploye = value;
                RaisePropertyChanged("CleEmploye");
            }
        }

        private string _login; 
        public string Login
        {
            get { return _login; }
            set
            {
                _login = value;
                RaisePropertyChanged("Login");
            }
        }

        public void Quitter()
        {
            App.Current.Windows[1].Close();
           
        }

        public void Ajouter()
        {
            Utilisateur utilisateur = new Utilisateur();
            utilisateur.NomUtilisateur = Login;
            utilisateur.NomGrade = "Employe";
            utilisateur.MotDePasseUtilisateur = ServiceUtilisateur.EncryypterSha512(MotDePasse);
            utilisateur.Cleemploye = CleEmploye;
            temporaire = "Connexion";

            foreach( Utilisateur element in listeUtilisateur)
            {
                listeCleEmployeUtilise.Add(element.Cleemploye);
            }
                       
            if (listenomutilisateur.Contains(Login))
            {
                temporaire = "Utilisateur";
                
            }

            if (listecleemploye.Contains(utilisateur.Cleemploye) != true)
            {
                temporaire = "CleEmployeNonValide";
            }

            if (listeCleEmployeUtilise.Contains(utilisateur.Cleemploye))
            {
                temporaire = "CleEmployeUtilisé";
            }
  

            switch (temporaire)
            {
                case "Utilisateur":
                    MessageBox.Show(" Nom d'utilisateur déjà présent ! \n Veuillez recommencez !");
                    break;
                case "Connexion":
                    ServiceUtilisateur.Ajouterutilisateur(utilisateur);
                    MessageBox.Show("Utilisateur Créer !");
                    App.Current.Windows[1].Close();
                    break;
                case "CleEmployeUtilisé":
                    MessageBox.Show("Clé Employé déjà utilisé ! \n Veuillez recommencer !");
                    break;
                case "CleEmployeNonValide":
                    MessageBox.Show("Clé Employé non valide ! \n Veuillez recommencer !");
                    break;
                default:                    
                    MessageBox.Show("Erreur je suis beau");
                    break;


            }

        }
        private void OuvrirInfos()
        {
            InfosViewModel.VerificationPageConnexion = false;
            Infos fenetre = new Infos();
            fenetre.Show();
            PrincipalViewModel.CompteurPage = 2;
        }

    }
}
