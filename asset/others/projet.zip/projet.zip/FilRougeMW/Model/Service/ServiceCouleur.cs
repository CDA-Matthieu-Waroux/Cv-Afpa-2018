﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using FilRougeMW.Model.Class;

namespace FilRougeMW.Model.Service
{
    class ServiceCouleur
    {
        private  static List<string> listeCouleur = new List<string>();

        internal  static List<string> ListeCouleur { get => listeCouleur; set => listeCouleur = value; }

        public static List<string>ChargeeDonneeCouleur()
        {

            string parametreConnexion = "Server=localhost;Database=sans_chauffeur;Uid=root;Pwd=;SslMode=none"; 
            MySqlConnection connexion = new MySqlConnection(parametreConnexion);
            MySqlDataReader lecture = null;
            try
            {
                connexion.Open();
                string requete = "ObtenirCouleur";
                MySqlCommand action = new MySqlCommand(requete, connexion);
                lecture = action.ExecuteReader();
                while (lecture.Read())
                {
                    string couleur =Convert.ToString(lecture["NOM_COULEUR"]);                                                            
                    listeCouleur.Add(couleur);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur de connection à la base de donnée ! " + ex);
            }
            finally
            {
                if (connexion.State == ConnectionState.Open)
                {
                    connexion.Close();
                }
            }



            return ListeCouleur;
        }
    }
}
