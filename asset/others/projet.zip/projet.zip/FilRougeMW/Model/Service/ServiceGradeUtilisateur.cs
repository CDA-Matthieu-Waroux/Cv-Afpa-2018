﻿using FilRougeMW.Model.Class;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace FilRougeMW.Model.Service
{
    class ServiceGradeUtilisateur
    {
        
    }
}
