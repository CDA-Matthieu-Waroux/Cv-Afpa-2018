﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace FilRougeMW.Model.Service
{
    class ServiceEmploye
    {
        private static ObservableCollection<string> listeClefEmploye = new ObservableCollection<string>();

        public static ObservableCollection<string> ListeClefEmploye { get => listeClefEmploye; set => listeClefEmploye = value; }

        public static ObservableCollection<string> ObtenirClefEmploye()
        {

            string parametreConnexion = "Server=localhost;Database=sans_chauffeur;Uid=root;Pwd=;SslMode=none";
            MySqlConnection connexion = new MySqlConnection(parametreConnexion);
            MySqlDataReader lecture = null;
            ListeClefEmploye.Clear();
            try
            {
                connexion.Open();
                string requete = "ObtenirCleEmploye";
                MySqlCommand action = new MySqlCommand(requete, connexion);
                lecture = action.ExecuteReader();
                while (lecture.Read())
                {
                    string clefEmploye = Convert.ToString(lecture["CLE_EMPLOYE"]);
                    listeClefEmploye.Add(clefEmploye);



                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur de connection à la base de donnée ! " + ex);
            }
            finally
            {
                if (connexion.State == ConnectionState.Open)
                {
                    connexion.Close();
                }
            }



            return ListeClefEmploye;
        }
    }
}
