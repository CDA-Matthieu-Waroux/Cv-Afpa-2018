﻿using FilRougeMW.Model.Class;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace FilRougeMW.Model.Service
{
    class ServiceAnneeFabrication
    {
        //Création et encapsulation d'une liste de chargement pour récuperer les données en base de donnée
        private static List<int> listeAnneFabrication = new List<int>();
        public static List<int> ListeAnneFabrication { get => listeAnneFabrication; set => listeAnneFabrication = value; }

        //Méthode        
        public static List<int> ChargeeDonneeAnneeFabrication()
        {
            string parametreConnexion = "Server=localhost;Database=sans_chauffeur;Uid=root;Pwd=;SslMode=none";
            MySqlConnection connexion = new MySqlConnection(parametreConnexion);
            MySqlDataReader lecture = null;
            try
            {
                connexion.Open();
                string requete = "ObtenirAnnee";
                MySqlCommand action = new MySqlCommand(requete, connexion);
                lecture = action.ExecuteReader();
                while (lecture.Read())
                {
                    int annee = Convert.ToInt32(lecture["ANNEE"]);
                   
                    listeAnneFabrication.Add(annee);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur de connection à la base de donnée ! " + ex);
            }
            finally
            {
                if (connexion.State == ConnectionState.Open)
                {
                    connexion.Close();
                }
            }
            return ListeAnneFabrication;
        }
    }
}
