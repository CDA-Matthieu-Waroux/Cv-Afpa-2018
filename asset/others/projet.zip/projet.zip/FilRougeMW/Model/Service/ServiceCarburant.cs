﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using FilRougeMW.Model.Class;

namespace FilRougeMW.Model.Service
{
    class ServiceCarburant
    {


        private static List<string> listeCarburant = new List<string>();

        internal  static List<string> ListeCarburant { get => listeCarburant; set => listeCarburant = value; }

        public static List<string> ChargeeDonneeCarburant()
        {

            string parametreConnexion = "Server=localhost;Database=sans_chauffeur;Uid=root;Pwd=;SslMode=none";
            MySqlConnection connexion = new MySqlConnection(parametreConnexion);
            MySqlDataReader lecture = null;
            try
            {
                connexion.Open();
                string requete = "ObtenirCarburant";
                MySqlCommand action = new MySqlCommand(requete, connexion);
                lecture = action.ExecuteReader();
                while (lecture.Read())
                {
                    string carburant = Convert.ToString(lecture["NOM_CARBURANT"]);
                   
                    listeCarburant.Add(carburant);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur de connection à la base de donnée ! " + ex);
            }
            finally
            {
                if (connexion.State == ConnectionState.Open)
                {
                    connexion.Close();
                }
            }



            return ListeCarburant;
        }
    }
}
