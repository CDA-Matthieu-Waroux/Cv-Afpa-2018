-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Mar 31 Juillet 2018 à 11:05
-- Version du serveur :  5.5.56-MariaDB
-- Version de PHP :  7.1.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `filrouge`
--

DELIMITER $$
--
-- Procédures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `AfficherOptionsByVoiture`(IN `OPTIONS` INT(99))
SELECT options.NOM_OPTION
FROM options
JOIN disposer on disposer.ID_OPTION=options.ID_OPTION
JOIN voiture on disposer.ID_VOITURE=voiture.ID_VOITURE
WHERE voiture.ID_VOITURE = OPTIONS$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AfficherUtilisateur`()
SELECT utilisateur.NOM_UTILISATEUR  
FROM utilisateur$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AfficherVoitureByID`(IN `VOITURE` INT(99))
SELECT voiture.ID_VOITURE,categorie.NOM_CATEGORIE, marque.NOM_MARQUE, modele.NOM_MODELE,voiture.PUISSANCE, 
voiture.PRIX_ACHAT, voiture.COTE_ARGUS, voiture.NOMBRE_PLACE, annee_fabrication.ANNEE, voiture.COTE_ARGUS, 
carburant.NOM_CARBURANT, couleur.NOM_COULEUR  
FROM voiture 
JOIN categorie on voiture.ID_CATEGORIE = categorie.ID_CATEGORIE
JOIN modele on voiture.ID_MODELE = modele.ID_MODELE 
JOIN marque on modele.ID_MARQUE = marque.ID_MARQUE 
JOIN couleur on voiture.ID_COULEUR = couleur.ID_COULEUR 
JOIN carburant on voiture.ID_CARBURANT = carburant.ID_CARBURANT 
JOIN annee_fabrication ON voiture.ID_ANNEE_FABRICATION = annee_fabrication.ID_ANNEE_FABRICATION 
Where voiture.ID_VOITURE = VOITURE$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AjouterOption`(IN `Options` VARCHAR(199))
INSERT INTO disposer(disposer.ID_OPTION,disposer.ID_VOITURE ) VALUES ((SELECT options.ID_OPTION FROM options WHERE options.NOM_OPTION = Options),(SELECT MAX(voiture.ID_VOITURE) FROM voiture))$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AjouterOptionByIdVoiture`(IN `Valeur` VARCHAR(199), IN `IdVoiture` INT(10))
INSERT INTO disposer(disposer.ID_VOITURE , disposer.ID_OPTION) VALUES(IdVoiture,(SELECT options.ID_OPTION FROM options WHERE options.NOM_OPTION = Valeur))$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AjouterUtilisateur`(IN `NOM` VARCHAR(199), IN `PASSWORDS` VARCHAR(199), IN `GRADE` VARCHAR(199))
INSERT INTO utilisateur 
VALUES 
(null,
 NOM,
 PASSWORDS,
 (SELECT grade_utilisateur.ID_GRADE_UTILISATEUR FROM grade_utilisateur WHERE grade_utilisateur.NOM_GRADE_UTILISATEUR = GRADE))$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AjouterVoiture`(IN `PUISSANCE` INT(10), IN `PRIX` INT(10), IN `COTE` INT(10), IN `PLACE` INT(5), IN `CARBURANT` VARCHAR(20), IN `MODELE` VARCHAR(99), IN `COULEUR` VARCHAR(30), IN `CATEGORIE` VARCHAR(20), IN `ANNEE` INT(5), IN `PHOTO` VARCHAR(199))
INSERT INTO `voiture` (`ID_VOITURE`, `PUISSANCE`,`PHOTO` ,`PRIX_ACHAT`, `COTE_ARGUS`, `NOMBRE_PLACE`,`ID_CARBURANT`,`ID_MODELE`, `ID_COULEUR` , `ID_CATEGORIE`, `ID_ANNEE_FABRICATION`)
VALUES (NULL, PUISSANCE,PHOTO, PRIX , COTE, PLACE,(SELECT carburant.ID_CARBURANT FROM carburant WHERE carburant.NOM_CARBURANT = CARBURANT), (SELECT modele.ID_MODELE FROM modele WHERE modele.NOM_MODELE = MODELE), (SELECT couleur.ID_COULEUR FROM couleur WHERE couleur.NOM_COULEUR = COULEUR),(SELECT categorie.ID_CATEGORIE FROM categorie WHERE categorie.NOM_CATEGORIE = CATEGORIE), (SELECT annee_fabrication.ID_ANNEE_FABRICATION FROM annee_fabrication WHERE annee_fabrication.ANNEE = ANNEE ))$$

CREATE DEFINER=`MatMoh`@`%` PROCEDURE `ModifierVoitureById`(IN `Modele` VARCHAR(199), IN `Puissance` INT(10), IN `Prix` INT(10), IN `Place` INT(10), IN `Annee` INT(10), IN `Carburant` VARCHAR(199), IN `Couleur` VARCHAR(199), IN `IdVoiture` INT(10), IN `CoteArgus` INT(10), IN `Categorie` VARCHAR(199), IN `Photo` VARCHAR(199))
UPDATE voiture
JOIN categorie on voiture.ID_CATEGORIE = categorie.ID_CATEGORIE
JOIN modele on voiture.ID_MODELE = modele.ID_MODELE
JOIN marque on modele.ID_MARQUE = marque.ID_MARQUE 
JOIN couleur on voiture.ID_COULEUR = couleur.ID_COULEUR 
JOIN carburant on voiture.ID_CARBURANT = carburant.ID_CARBURANT
JOIN annee_fabrication ON voiture.ID_ANNEE_FABRICATION = annee_fabrication.ID_ANNEE_FABRICATION
SET voiture.ID_MODELE =(SELECT modele.ID_MODELE  FROM modele WHERE modele.NOM_MODELE = Modele ) ,
voiture.PUISSANCE = Puissance ,
voiture.Photo = Photo,
voiture.PRIX_ACHAT = Prix , 
voiture.COTE_ARGUS = CoteArgus ,
voiture.NOMBRE_PLACE = Place ,
voiture.ID_ANNEE_FABRICATION=(SELECT annee_fabrication.ID_ANNEE_FABRICATION FROM annee_fabrication WHERE annee_fabrication.ANNEE=  Annee) ,
voiture.ID_CARBURANT = (SELECT carburant.ID_CARBURANT FROM carburant WHERE carburant.NOM_CARBURANT = Carburant) ,
voiture.ID_COULEUR = (SELECT couleur.ID_COULEUR FROM couleur WHERE couleur.NOM_COULEUR = Couleur) ,
voiture.ID_CATEGORIE = (SELECT categorie.ID_CATEGORIE FROM categorie WHERE categorie.NOM_CATEGORIE = Categorie)
WHERE voiture.ID_VOITURE = IdVoiture$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenirAnnee`()
SELECT annee_fabrication.ANNEE from annee_fabrication$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenirCarburant`()
SELECT carburant.NOM_CARBURANT
FROM carburant$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenirCategorie`()
Select categorie.NOM_CATEGORIE FROM categorie$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenirCleEmploye`()
Select employe.CLE_EMPLOYE FROM employe$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenirCouleur`()
Select couleur.NOM_COULEUR FROM couleur$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenirInfosVoiture`()
BEGIN
SELECT voiture.ID_VOITURE, marque.NOM_MARQUE, modele.NOM_MODELE, voiture.PUISSANCE, voiture.PRIX_ACHAT, voiture.COTE_ARGUS, voiture.NOMBRE_PLACE, annee_fabrication.ANNEE, carburant.NOM_CARBURANT, couleur.NOM_COULEUR, voiture.Photo , categorie.NOM_CATEGORIE
FROM voiture 
JOIN modele on voiture.ID_MODELE=modele.ID_MODELE 
JOIN marque on modele.ID_MARQUE=marque.ID_MARQUE 
JOIN couleur on voiture.ID_COULEUR=couleur.ID_COULEUR 
JOIN carburant on voiture.ID_CARBURANT=carburant.ID_CARBURANT 
JOIN annee_fabrication ON voiture.ID_ANNEE_FABRICATION = annee_fabrication.ID_ANNEE_FABRICATION  
JOIN categorie on categorie.ID_CATEGORIE = voiture.ID_CATEGORIE
ORDER BY marque.NOM_MARQUE;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenirInfoUtilisateur`(IN `login` VARCHAR(199))
SELECT utilisateur.NOM_UTILISATEUR, utilisateur.MOT_PASSE_UTILISATEUR ,utilisateur.ID_GRADE_UTILISATEUR
FROM utilisateur
WHERE utilisateur.NOM_UTILISATEUR = login
LIMIT 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenirMarque`()
SELECT marque.ID_MARQUE , marque.NOM_MARQUE
FROM marque$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenirModele`()
SELECT modele.NOM_MODELE , modele.ID_MARQUE from modele$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenirModeleByMarque`(IN `MARQUE` VARCHAR(199))
Select modele.NOM_MODELE FROM modele JOIN marque on modele.ID_MARQUE= marque.ID_MARQUE Where marque.NOM_MARQUE = MARQUE$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenirOptions`()
SELECT options.NOM_OPTION FROM options$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenirUtilisateur`()
SELECT utilisateur.NOM_UTILISATEUR , utilisateur.CLE_EMPLOYE FROM utilisateur$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SupprimerOptionsByIdVoiture`(IN `IdVoiture` INT)
DELETE disposer FROM disposer JOIN voiture on disposer.ID_VOITURE=voiture.ID_VOITURE WHERE voiture.ID_VOITURE=IdVoiture$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SupprimerVoiture`(IN `valeur` INT(10))
begin
DELETE from disposer where ID_Voiture = valeur;
DELETE FROM voiture WHERE ID_Voiture = valeur;
End$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SupprimerVoitureByID`(IN `Valeur` INT(10))
BEGIN 
DELETE FROM disposer WHERE disposer.ID_VOITURE=Valeur;
DELETE FROM voiture WHERE voiture.ID_VOITURE=Valeur;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `annee_fabrication`
--

CREATE TABLE IF NOT EXISTS `annee_fabrication` (
  `ID_ANNEE_FABRICATION` int(11) NOT NULL,
  `ANNEE` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `annee_fabrication`
--

INSERT INTO `annee_fabrication` (`ID_ANNEE_FABRICATION`, `ANNEE`) VALUES
(1, 2018),
(2, 2017),
(3, 2016),
(4, 2015),
(5, 2014),
(6, 2013),
(7, 2012),
(8, 2011),
(9, 2010),
(10, 2009);

-- --------------------------------------------------------

--
-- Structure de la table `carburant`
--

CREATE TABLE IF NOT EXISTS `carburant` (
  `ID_CARBURANT` int(11) NOT NULL,
  `NOM_CARBURANT` varchar(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `carburant`
--

INSERT INTO `carburant` (`ID_CARBURANT`, `NOM_CARBURANT`) VALUES
(1, 'Diesel'),
(2, 'Electrique'),
(3, 'Essence'),
(4, 'Ethanol'),
(5, 'GPL'),
(6, 'Hybride');

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE IF NOT EXISTS `categorie` (
  `ID_CATEGORIE` int(11) NOT NULL,
  `NOM_CATEGORIE` varchar(99) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `categorie`
--

INSERT INTO `categorie` (`ID_CATEGORIE`, `NOM_CATEGORIE`) VALUES
(1, 'SUV/4X4'),
(2, 'Berline'),
(3, 'Break'),
(4, 'Coupe/Sport'),
(5, 'Luxe'),
(6, 'Monospace'),
(8, 'mateub');

-- --------------------------------------------------------

--
-- Structure de la table `couleur`
--

CREATE TABLE IF NOT EXISTS `couleur` (
  `ID_COULEUR` int(11) NOT NULL,
  `NOM_COULEUR` varchar(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `couleur`
--

INSERT INTO `couleur` (`ID_COULEUR`, `NOM_COULEUR`) VALUES
(1, 'Beige'),
(2, 'Blanc'),
(3, 'Bleu'),
(4, 'Bordeaux'),
(5, 'Gris'),
(6, 'Fushia'),
(7, 'Jaune'),
(8, 'Marron'),
(9, 'Noir'),
(10, 'OR '),
(11, 'Orange'),
(12, 'Rouge'),
(13, 'Vert'),
(14, 'Violet'),
(15, 'Turquoise');

-- --------------------------------------------------------

--
-- Structure de la table `disposer`
--

CREATE TABLE IF NOT EXISTS `disposer` (
  `ID_OPTION` int(11) NOT NULL,
  `ID_VOITURE` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `disposer`
--

INSERT INTO `disposer` (`ID_OPTION`, `ID_VOITURE`) VALUES
(1, 4),
(1, 11),
(1, 17),
(1, 24),
(1, 33),
(1, 34),
(1, 42),
(1, 48),
(1, 69),
(1, 79),
(1, 81),
(1, 82),
(1, 83),
(1, 91),
(1, 104),
(1, 108),
(1, 130),
(1, 133),
(1, 149),
(1, 163),
(1, 164),
(1, 175),
(1, 178),
(1, 202),
(1, 204),
(1, 206),
(1, 207),
(1, 208),
(1, 219),
(1, 237),
(1, 238),
(1, 432),
(1, 433),
(1, 436),
(1, 443),
(2, 1),
(2, 2),
(2, 3),
(2, 5),
(2, 6),
(2, 7),
(2, 8),
(2, 9),
(2, 10),
(2, 16),
(2, 19),
(2, 20),
(2, 23),
(2, 25),
(2, 27),
(2, 28),
(2, 29),
(2, 31),
(2, 32),
(2, 35),
(2, 36),
(2, 40),
(2, 41),
(2, 43),
(2, 49),
(2, 51),
(2, 52),
(2, 53),
(2, 54),
(2, 55),
(2, 58),
(2, 59),
(2, 60),
(2, 61),
(2, 63),
(2, 64),
(2, 65),
(2, 66),
(2, 72),
(2, 73),
(2, 74),
(2, 78),
(2, 80),
(2, 84),
(2, 87),
(2, 88),
(2, 93),
(2, 94),
(2, 96),
(2, 97),
(2, 98),
(2, 102),
(2, 103),
(2, 105),
(2, 106),
(2, 107),
(2, 109),
(2, 110),
(2, 111),
(2, 112),
(2, 117),
(2, 118),
(2, 119),
(2, 120),
(2, 121),
(2, 124),
(2, 125),
(2, 127),
(2, 129),
(2, 131),
(2, 132),
(2, 134),
(2, 135),
(2, 136),
(2, 137),
(2, 140),
(2, 141),
(2, 142),
(2, 143),
(2, 144),
(2, 145),
(2, 146),
(2, 147),
(2, 148),
(2, 150),
(2, 151),
(2, 153),
(2, 155),
(2, 157),
(2, 159),
(2, 160),
(2, 161),
(2, 162),
(2, 165),
(2, 168),
(2, 170),
(2, 173),
(2, 174),
(2, 176),
(2, 177),
(2, 179),
(2, 181),
(2, 183),
(2, 184),
(2, 187),
(2, 188),
(2, 189),
(2, 190),
(2, 191),
(2, 192),
(2, 194),
(2, 196),
(2, 201),
(2, 203),
(2, 205),
(2, 209),
(2, 210),
(2, 211),
(2, 212),
(2, 214),
(2, 217),
(2, 218),
(2, 221),
(2, 222),
(2, 223),
(2, 226),
(2, 229),
(2, 230),
(2, 231),
(2, 236),
(2, 240),
(2, 242),
(2, 243),
(2, 244),
(2, 245),
(2, 246),
(2, 247),
(2, 248),
(2, 249),
(2, 250),
(2, 252),
(2, 253),
(2, 254),
(2, 255),
(2, 257),
(2, 258),
(2, 259),
(2, 260),
(2, 261),
(2, 262),
(2, 263),
(2, 264),
(2, 266),
(2, 267),
(2, 269),
(2, 270),
(2, 271),
(2, 272),
(2, 276),
(2, 277),
(2, 278),
(2, 283),
(2, 284),
(2, 289),
(2, 293),
(2, 294),
(2, 295),
(2, 296),
(2, 297),
(2, 298),
(2, 301),
(2, 303),
(2, 304),
(2, 305),
(2, 308),
(2, 313),
(2, 314),
(2, 315),
(2, 316),
(2, 318),
(2, 320),
(2, 321),
(2, 322),
(2, 325),
(2, 326),
(2, 327),
(2, 328),
(2, 329),
(2, 330),
(2, 331),
(2, 332),
(2, 333),
(2, 334),
(2, 335),
(2, 336),
(2, 337),
(2, 338),
(2, 339),
(2, 340),
(2, 341),
(2, 342),
(2, 343),
(2, 344),
(2, 345),
(2, 346),
(2, 348),
(2, 350),
(2, 358),
(2, 359),
(2, 361),
(2, 363),
(2, 364),
(2, 365),
(2, 367),
(2, 368),
(2, 372),
(2, 373),
(2, 374),
(2, 376),
(2, 377),
(2, 378),
(2, 379),
(2, 380),
(2, 381),
(2, 382),
(2, 383),
(2, 384),
(2, 385),
(2, 386),
(2, 387),
(2, 388),
(2, 389),
(2, 390),
(2, 391),
(2, 392),
(2, 393),
(2, 394),
(2, 395),
(2, 396),
(2, 397),
(2, 398),
(2, 399),
(2, 400),
(2, 401),
(2, 402),
(2, 403),
(2, 404),
(2, 405),
(2, 406),
(2, 407),
(2, 408),
(2, 409),
(2, 410),
(2, 411),
(2, 412),
(2, 413),
(2, 414),
(2, 417),
(2, 418),
(2, 419),
(2, 421),
(2, 422),
(2, 423),
(2, 426),
(2, 430),
(2, 434),
(2, 435),
(2, 437),
(2, 441),
(2, 442),
(2, 448),
(2, 450),
(2, 452),
(2, 455),
(2, 458),
(3, 12),
(3, 37),
(3, 47),
(3, 68),
(3, 70),
(3, 77),
(3, 86),
(3, 89),
(3, 90),
(3, 115),
(3, 116),
(3, 128),
(3, 138),
(3, 139),
(3, 158),
(3, 166),
(3, 167),
(3, 169),
(3, 180),
(3, 182),
(3, 185),
(3, 193),
(3, 197),
(3, 198),
(3, 199),
(3, 200),
(3, 213),
(3, 216),
(3, 220),
(3, 224),
(3, 228),
(3, 234),
(3, 235),
(3, 239),
(3, 317),
(3, 319),
(3, 347),
(3, 369),
(3, 370),
(3, 371),
(3, 431),
(3, 438),
(3, 444),
(3, 456),
(3, 457),
(4, 13),
(4, 22),
(4, 38),
(4, 46),
(4, 57),
(4, 67),
(4, 76),
(4, 85),
(4, 114),
(4, 126),
(4, 152),
(4, 154),
(4, 156),
(4, 171),
(4, 172),
(4, 186),
(4, 195),
(4, 215),
(4, 232),
(4, 233),
(4, 360),
(4, 424),
(4, 425),
(4, 439),
(4, 449),
(4, 459),
(4, 460),
(5, 14),
(5, 21),
(5, 30),
(5, 45),
(5, 62),
(5, 75),
(5, 99),
(5, 100),
(5, 113),
(5, 225),
(5, 241),
(5, 251),
(5, 256),
(5, 265),
(5, 268),
(5, 273),
(5, 274),
(5, 275),
(5, 279),
(5, 280),
(5, 281),
(5, 282),
(5, 285),
(5, 286),
(5, 287),
(5, 288),
(5, 290),
(5, 291),
(5, 292),
(5, 299),
(5, 300),
(5, 302),
(5, 306),
(5, 307),
(5, 309),
(5, 310),
(5, 311),
(5, 312),
(5, 323),
(5, 324),
(5, 349),
(5, 351),
(5, 352),
(5, 353),
(5, 354),
(5, 355),
(5, 356),
(5, 357),
(5, 362),
(5, 366),
(5, 375),
(5, 415),
(5, 416),
(5, 440),
(5, 460),
(6, 15),
(6, 18),
(6, 26),
(6, 39),
(6, 44),
(6, 50),
(6, 56),
(6, 71),
(6, 92),
(6, 95),
(6, 101),
(6, 122),
(6, 123),
(6, 227),
(6, 420),
(6, 427),
(6, 428),
(6, 429),
(6, 445),
(6, 446),
(6, 447),
(6, 451),
(6, 453),
(6, 454);

-- --------------------------------------------------------

--
-- Structure de la table `employe`
--

CREATE TABLE IF NOT EXISTS `employe` (
  `ID_EMPLOYE` int(11) NOT NULL,
  `NOM_EMPLOYE` varchar(199) DEFAULT NULL,
  `PRENOM_EMPLOYE` varchar(199) DEFAULT NULL,
  `CLE_EMPLOYE` varchar(199) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `employe`
--

INSERT INTO `employe` (`ID_EMPLOYE`, `NOM_EMPLOYE`, `PRENOM_EMPLOYE`, `CLE_EMPLOYE`) VALUES
(1, 'Waroux', 'Matthieu', 'XXX000000000XXX'),
(2, 'DABEK', 'NICOLAS', 'XXX0123456789XXX'),
(5, 'Julien', 'Venici', 'XXX000000001XXX'),
(6, 'Momo', 'C#', 'XXX000000002XXX'),
(7, 'Ryad', 'Le iencli', 'ZZZ999999999ZZZ'),
(8, 'Richtard', 'Salace', 'XXX696969696XXX'),
(9, 'Emmanuelle', 'Le garçon', 'aaa');

-- --------------------------------------------------------

--
-- Structure de la table `grade_utilisateur`
--

CREATE TABLE IF NOT EXISTS `grade_utilisateur` (
  `ID_GRADE_UTILISATEUR` int(11) NOT NULL,
  `NOM_GRADE_UTILISATEUR` varchar(99) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `grade_utilisateur`
--

INSERT INTO `grade_utilisateur` (`ID_GRADE_UTILISATEUR`, `NOM_GRADE_UTILISATEUR`) VALUES
(1, 'Admin'),
(2, 'Employe'),
(3, 'Client');

-- --------------------------------------------------------

--
-- Structure de la table `marque`
--

CREATE TABLE IF NOT EXISTS `marque` (
  `ID_MARQUE` int(11) NOT NULL,
  `NOM_MARQUE` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `marque`
--

INSERT INTO `marque` (`ID_MARQUE`, `NOM_MARQUE`) VALUES
(1, 'Abarth'),
(2, 'Alpha Romeo'),
(3, 'Alpina'),
(4, 'Artega'),
(5, 'Aston Martin'),
(6, 'Audi'),
(7, 'Bentley'),
(8, 'BMW'),
(9, 'Chevrolet'),
(10, 'Citroën'),
(11, 'DS'),
(12, 'Ferrari'),
(13, 'Fisker'),
(14, 'Ford'),
(15, 'Honda'),
(16, 'Hyundai'),
(17, 'Infinity'),
(18, 'Isuzu'),
(19, 'Jaguar '),
(20, 'Jeep'),
(21, 'Kia'),
(22, 'Lancia'),
(23, 'Land Rover'),
(24, 'Lamborghini'),
(25, 'Lexus'),
(26, 'Lotus'),
(27, 'Maserati'),
(28, 'Mastretta'),
(29, 'Mazda'),
(30, 'McLaren'),
(31, 'Mercedes'),
(32, 'Morgan'),
(33, 'Mitsubishi'),
(34, 'Nissan'),
(35, 'Opel'),
(36, 'Peugeot'),
(37, 'PGO'),
(38, 'Porsche'),
(39, 'Renault'),
(40, 'Rolls-Royce'),
(41, 'Seat'),
(42, 'Skoda'),
(43, 'Subaru'),
(44, 'Suzuki'),
(45, 'Tesla'),
(46, 'Toyota'),
(47, 'Volksvagen'),
(48, 'Volvo');

-- --------------------------------------------------------

--
-- Structure de la table `modele`
--

CREATE TABLE IF NOT EXISTS `modele` (
  `ID_MODELE` int(11) NOT NULL,
  `NOM_MODELE` varchar(199) NOT NULL,
  `ID_MARQUE` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=460 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `modele`
--

INSERT INTO `modele` (`ID_MODELE`, `NOM_MODELE`, `ID_MARQUE`) VALUES
(1, 'Stelvio 2.2 D Turbo 210 Q4 AT8 Sport Edition ', 2),
(2, 'XD3 3.0d 6cyl Biturbo 350 Switch-Tronic ', 3),
(3, 'Q7 3.0 V6 TDI e-tron 374 Quattro Tiptronic 8 Avus', 6),
(4, 'Q5 2.0 TDI 190 Quattro Avus', 6),
(5, 'Q3 2.0 TFSI 220 Quattro S tronic 7 Ambition Luxe', 6),
(6, 'Q2 2.0 TDI 190 Quattro S tronic 7 Launch Edition Luxe', 6),
(7, 'Bentayga 6.0i W12 608', 7),
(8, 'X6 xDrive30d 313ch', 8),
(9, 'X5 sDrive25d  BVA8 Lounge Plus', 8),
(10, 'X4 M40i', 8),
(11, 'X3 sDrive18dBVM6 Luxury', 8),
(12, 'X2 sDrive 18d BVM6 M Sport', 8),
(13, 'X1 sDrive18i Business', 8),
(14, 'Trax 1.7 VCDi 4x4 LT+', 9),
(15, 'Orlando 1.4 T LTZ+', 9),
(16, 'Captiva 2.2 VCDI AWD BVA LTZ', 9),
(17, 'Ranger Double Cabine 3.2 TDCi Wildtrak', 14),
(18, 'Ranger Simple Cabine 2.2 TDCi XL Pack', 14),
(19, 'Ranger Super Cabine 3.2 TDCi  Wildtrak', 14),
(20, 'Edge 2.0 TDCi AWD PowerShift Intelligent ST Line ', 14),
(21, 'EcoSport 1.0  EcoBoost BVM6 ST-Line Noir/Tiger', 14),
(22, 'Kuga 1.5 EcoBoost BVM6 Vignale', 14),
(23, 'iX35 2.0 FUEL CELL', 16),
(24, 'Tucson 2.0 CRDi 4WD Executive ', 16),
(25, 'Santa Fe 2.2 CRDi 4WD BVA Executive', 16),
(26, 'Kona 1.0 T-GDi Executive', 16),
(27, 'QX30 2.0t AWD 7DCT Executive', 17),
(28, 'QX50 3.0d V6 BVA GT Premium', 17),
(29, 'QX70 3.7i V6 BVA S Design', 17),
(30, 'D-Max 2.5 D 4x4 Quasar', 18),
(31, 'F-Pace 3.0i V6 Suralimenté Première Edition', 19),
(32, 'E-Pace 2.0 D R-Dynamic HSE', 19),
(33, 'Renegade 1.4i MultiAir Limited Advanced Technologies', 20),
(34, 'Renegade 1.4i MultiAir Limited Advanced Technologies', 20),
(35, 'Cherokee 3.2i V6 Pentastar Active Drive Lock BVA Trailhawk', 20),
(36, 'Grand Cherokee 3.6i V6 Pentastar 284 Flexfuel BVA Summit', 20),
(37, 'Sorento 2.2 CRDi BVM6 Premium', 21),
(38, 'Sportage 2.0 CRDi GT Line Pack Premium ', 21),
(39, 'Stonic 1.6 CRDi Premium', 21),
(40, 'Evoque Mark III 2.0 Si4 BVA Autobiography', 23),
(41, 'Evoque Cabriolet Mark III 2.0 td4 BVA HSE Dynamic', 23),
(42, 'Evoque Coupé Mark III 2.0 td4 HSE Dynamic', 23),
(43, 'Sport Mark V 3.0 SDV6 354 Hybride BVA HSE', 23),
(44, 'Defender 110 Mark VI 2.2 td4 122 E', 23),
(45, 'Defender 110 Pick-Up Mark VI 2.2 td4 122 E', 23),
(46, 'Defender 110 Pick-Up Double Cabine Mark VI 2.2 td4 122 SE', 23),
(47, 'Defender 110 SW Mark VI 2.2 td4 122 Adventure Edition', 23),
(48, 'Defender 130 Mark V 2.2 td4 122 E', 23),
(49, 'Discovery 3.0 V6 Si6 BVA8 SE', 23),
(50, 'Discovery Sport 2.0 td4 Executive', 23),
(51, 'Velar 2.0i P250 BVA SE', 23),
(52, 'SWB Mark VII 3.0 tdV6 BVA HSE ', 23),
(53, 'NX 300h 2.5i 155 4WD e-CVT Executive', 25),
(54, 'RX 450h 3.5 V6 E-Four e-CVT Sport Edition', 25),
(55, 'Levante 3.0 V6 Bi-Turbo 430 S Q4 BVA GranSport', 27),
(56, 'CX-5 2.0i Skyactiv-G Sélection', 29),
(57, 'X 220D 4x4 Progressive', 31),
(58, 'GLS 350 d 258ch 4Matic 9G-Tronic Executive', 31),
(59, 'GL 63 AMG  4-Matic BVA', 31),
(60, 'G Long G 63 AMG Long BVA Edition 463', 31),
(61, 'G Long G 350 d Long', 31),
(62, 'GLK 220 CDI BlueEfficiency Fascination', 31),
(63, 'GLE GLE 500 e 4Matic BVA Fascination ', 31),
(64, 'GLE Coupé 350 d Coupé 4Matic BVA Fascination', 31),
(65, 'GLC 350 e 4-Matic 7G-DCT Sportline', 31),
(66, 'GLC 350 e Coupé 4Matic 7G-Tronic + Fascination', 31),
(67, 'GLA 250 Fascination', 31),
(68, 'L200 Pick-Up 2.5 TD Inform Clim', 33),
(69, 'L200 Pick-Up Club Cabine 2.4 DI-D INTENSE', 33),
(70, 'L200 Pick-Up Club Cabine 2.4 DI-D Inform Clim', 33),
(71, 'Eclipse Cross 1.5 MIVEC 2WD BVM6 Instyle', 33),
(72, 'Outlander 2.0i 200 PHEV Hybride rechargeable BVA Instyle', 33),
(73, 'Pajero Court 3.2 DI-D 190 BVA Invite', 33),
(74, 'Pajero Long 3.2 DI-D 190 BVA Instyle', 33),
(75, 'ASX 1.6 115 4x2 S-Edition', 33),
(76, 'NP300 Navara 2.3 dCi 190 Euro 6 Double Cab Tekna', 34),
(77, 'Navara 3.0 V6 dCi 231 BVA Double Cab Ultimate Edition ', 34),
(78, 'Pathfinder 3.0 V6 dCi 231 Euro 5 BVA', 34),
(79, 'Pathfinder Société 2.5 dCi 190 Euro 5 SE  connect Premium', 34),
(80, 'Murano 3.5i V6 255 All-Mode 4x4-i CVT AM 2012', 34),
(81, 'X-Trail 2.0 dCi 177 All-Mode 4x4-i N-Connecta ', 34),
(82, 'Qashqai 1.6 dCi 130 Intelligent 4x4 Tekna+', 34),
(83, 'Juke 1.6e DIG-T 218 Nismo RS', 34),
(84, 'Grandland X 2.0 D 177 BVA8 Ultimate', 35),
(85, ' Mokka X 1.4i Turbo 140 GPL Ecotec 4x2 Innovation', 35),
(86, 'Crossland X 1.5 D 102 Design', 35),
(87, 'Cayenne 3.0i V6 416 E-Hybrid Tiptronic S Platinium Edition', 38),
(88, 'Macan 3.6i V6 400 PDK GTS', 38),
(89, ' Grand Vitara 1.9 DDiS 129', 44),
(90, 'Vitara 1.6 DDiS VVT 120 AllGrip Cooper Edition ', 44),
(91, 'S-Cross 1.4i Boosterjet 140 4WD Style', 44),
(92, 'SX4 S-Cross 1.6 DDiS 120 Pack SE', 44),
(93, 'Levorg 1.6i Turbo 170 Lineartronic Exclusive', 43),
(94, 'Hi Lux Double Cabine 2.4 D-4D 150 4WD BVA Legende Sport', 46),
(95, 'Land Cruiser 3.0 D-4D 177 Life', 46),
(96, 'C-HR 122h Hybride 98 BVA Collection', 46),
(97, 'RAV 4 Hybride 197 2WD BVA Hybrid One', 46),
(98, 'T-Roc 1.5 TSI 150 EVO DSG7 Carat Exclusive', 47),
(99, 'Tiguan All Space 2.0 TDI 150 Carat Exclusive', 47),
(100, 'Amarok Double Cabine 3.0 TDI 204 4Motion BVM6 Cara', 47),
(101, 'XC40 T3 156 Inscription Luxe', 48),
(102, 'XC60 2.0i T8 Twin Engine 320+87 Geartronic 8 Inscription', 48),
(103, 'Giulia 2.2 JTD 210 Q4 AT8 Veloce', 2),
(104, '159 1.7i Turbo 200 TI', 2),
(105, 'Giulietta 2.0 JTDm 175 TCT Imola', 2),
(106, 'S6 4.0 V8 TFSI COD 450 Quattro S tronic 7', 6),
(107, 'S5 Sportback 3.0 V6 TFSI 354 Quattro Tiptronic 8', 6),
(108, 'S3 Berline 2.0 TFSI 310 Quattro', 6),
(109, 'RS7 Sportback 4.0 V8 TFSI COD 605 Quattro Tiptronic 8', 6),
(110, 'RS3 Berline 2.5 TFSI 400 Quattro S tronic 7', 6),
(111, 'A8 L 50 TDI 286 Quattro Tiptronic 8 Avus Extended Limousine', 6),
(112, 'A7 Sportback 3.0 V6 BiTDI 320 Quattro Tiptronic 8 Avus', 6),
(113, 'A6 2.0 TDI 150 Ultra Avus', 6),
(114, 'A5 2.0 TDI 190 Quattro Avus', 6),
(115, 'A5 Sportback 2.0 TDI 190 Avus', 6),
(116, 'A4 2.0 TDI 190 Ultra Design', 6),
(117, 'Série 7 740e 326ch iPerformance BVA M Sport', 8),
(118, 'Série 7 L 750iL xDrive L 450ch BVA Exclusive', 8),
(119, 'Série 6 Gran Turismo 640d xDrive Gran Turismo 320ch BVA8 M Sport', 8),
(120, 'Série 5 530e 252ch iPerformance BVA8 M Sport', 8),
(121, 'Série 5 Gran Turismo 535d xDrive Gran Turismo 313ch BVA M Sport', 8),
(122, 'Série 3 320d xDrive 190ch Luxury Pack Luxury Purity', 8),
(123, 'Série 3 Gran Turismo 320d xDrive Gran Turismo 190ch Luxury', 8),
(124, 'DS5 2.0 Hybrid4 163 ETG6 Sport Chic', 10),
(125, 'C6 3.0 V6 HDi 240 FAP BVA Exclusive', 10),
(126, 'C5 2.0 BlueHDi 150 Hydractive Exclusive', 10),
(127, 'DS5 2.0i Hybrid4 163 4x4 ETG6 Sport Chic', 11),
(128, 'Mondeo 2.0 TDCi 150 BVM6 ST Line ', 14),
(129, 'Mondeo Hybrid 2.0 Hybrid 177 BVA Titanium ', 14),
(130, 'Mondeo Vignale 2.0 TDCi 180', 14),
(131, 'Genesis 3.8 V6 GDi 315 HTRAC BVA ', 16),
(132, 'Ioniq Electric 120 BVA Executive', 16),
(133, 'i40 1.7 CRDi 141 Blue Drive Creative', 16),
(134, 'Q50 S Hybrid 306 AWD BVA Sport Tech', 17),
(135, 'Q70 Hybrid 3.5i V6 306 BVA Premium Tech', 17),
(136, 'XJ 3.0 D V6 300 BVA8 Autobiography Empattement Long', 19),
(137, 'XF 3.0i V6 380 AWD BVA S ', 19),
(138, 'XE 2.0 D 180 Portfolio', 19),
(139, 'Rio 1.0 T-GDi 120 GT Line Premium', 21),
(140, 'Optima 2.0 GDi 205 Hybride Rechargeable BVA6 Ultimate Business', 21),
(141, 'Stinger 2.2 CRDi 200 4x4 BVA8 GT Line Pack Premium', 21),
(142, 'Thema 3.0 V6 MultiJet II 239 BVA Executive ', 22),
(143, 'CT 200h 1.8i 99 BVA Executive', 25),
(144, 'IS 300h 2.5i 223 BVA F Sport Executive', 25),
(145, 'GS 450h 3.5i V6 292 BVA Luxe', 25),
(146, 'Quattroporte 3.0 D V6 Turbo 275 BVA GranSport', 27),
(147, 'Ghibli 3.0 D V6 Turbo 275 BVA', 27),
(148, '6 2.2 SkyActiv-D 175 BVA6 Sélection', 29),
(149, '3 2.2 SkyActiv-D 150 Sélection', 29),
(150, 'S 400 Hybrid 306ch BVA Executive ', 31),
(151, 'S 500 e L 333ch BVA Executive (Limousine)', 31),
(152, 'E 200 184ch Fascination', 31),
(153, 'CLS 350 d 258ch 4Matic BVA Sportline', 31),
(154, 'CLA 200 d 136ch Business Executive Edition', 31),
(155, 'C 350 e 211ch 7G-Tronic Fascination', 31),
(156, 'Pulsar 1.5 dCi 110 N-Vision', 34),
(157, 'Leaf Electrique 150 (40kWh) BVA Tekna ', 34),
(158, 'Insignia 1.6i Turbo 170 Cosmo', 35),
(159, 'Astra 1.6 CDTI 136 BVA6 S', 35),
(160, 'Insignia Grand Sport 2.0 CDTI 170 BlueInjection AT8 Elite', 35),
(161, 'Ampera Electrique 111 kW BVA Cosmo Pack', 35),
(162, '508 2.0 HDi 163 + Electric 37cv ETG6 Féline', 36),
(163, 'Talisman 1.6 dCi 130 Energy Initiale Paris ', 39),
(164, 'Latitude 2.0i 150 Energy Initiale', 39),
(165, 'Renault Laguna 2.0 dCi 175 BVA Intens', 39),
(166, 'Mégane 1.2i TCe 130 Energy Zen', 39),
(167, 'Toledo 1.0 TSI 110 Premium', 41),
(168, 'Leon 2.0 TSI 300 DSG6 Cupra R', 41),
(169, 'Ibiza 1.6 TDI 115 BVM6 Xcellence', 41),
(170, 'Superb 2.0 TSI 280 4x4 DSG6 Laurin&Klement', 42),
(171, 'Rapid 1.6 TDI 116 CR FAP Green Tec Edition Tour de France ', 42),
(172, 'Legacy Boxer Diesel 2.0D Sport Club', 43),
(173, 'XV 2.0i 150 Lineartronic Luxury ', 43),
(174, 'Model S P100DL 100 kWh Ludicrous', 45),
(175, 'Avensis 143 D-4D Lounge', 46),
(176, 'Auris 136h Hybride 98 BVA Lounge', 46),
(177, ' Phaeton 3.0 V6 TDI 140 FAP 4Motion Tiptronic', 47),
(178, 'Arteon 2.0 TD BlueMotion Technology BVM6 Elegance Exclusive', 47),
(179, 'Passat 1.4 TSI 218 Hybride DSG6 GTE', 47),
(180, 'Passat CC 1.4 TSI 150 Carat Edition', 47),
(181, 'Jetta 1.4 TSI 170 Hybride BlueMotion Technology DSG7 Carat', 47),
(182, 'Golf 1.4 TSI MultiFuel E85 125 Sound', 47),
(183, 'e-Golf Electrique 136 BVA Electrique', 47),
(184, 'S90 2.0i T8 Twin Engine 320+87 Geartronic 8 Inscription Luxe', 48),
(185, 'S80 2.0 D4 181 Summum', 48),
(186, 'S60 1.6i T3 152 Momentum', 48),
(187, 'S6 Avant 4.0 V8 TFSI COD 420 Quattro S tronic 7', 6),
(188, 'S3 Sportback 2.0 TFSI 310 Quattro S tronic 7', 6),
(189, 'RS6 Avant 4.0 V8 TFSI 605 Quattro Tiptronic 8 Performance', 6),
(190, 'RS4 Avant 2.9 V6 TFSI 450 Tiptronic 8', 6),
(191, 'RS3 Sportback 2.5 TFSI 400 Quattro S tronic 7', 6),
(192, 'A6 Allroad Quattro V6 3.0 TDI 218 S tronic Avus', 6),
(193, 'A6 Avant 2.0 TDI 190 Ultra Business Executive', 6),
(194, 'A4 Allroad Quattro 3.0 V6 TDI 272 DPF Tiptronic Design Luxe', 6),
(195, 'A4 Avant 2.0 TDI 190 Ultra Design Luxe', 6),
(196, 'A3 Sportback 1.4 TFSI e-tron 204 S tronic 6 Business line ', 6),
(197, 'A3 Berline 2.0 TDI 150 Quattro Design Luxe', 6),
(198, 'Série 5 Touring 520d Touring 190ch M Sport', 8),
(199, 'Série 3 Touring 320d xDrive Touring 190ch Business Design', 8),
(200, 'C5 CrossTourer 2.0 BlueHDi 150 Hydractive Exclusive', 10),
(201, 'C5 Tourer 2.0 BlueHDi 180 EAT6 Hydractive Exclusive', 10),
(202, 'Mondeo SW 1.5i 160 EcoBoost Titanium', 14),
(203, 'Mondeo Vignale SW 2.0 TDCi 150 PowerShift', 14),
(204, 'Civic Tourer 1.6 i-DTEC 120 Sport ', 15),
(205, 'i30 SW 1.6 CRDi 136 DCT-7 Creative', 16),
(206, 'i40 SW 1.7 CRDi 141 Blue Drive Executive', 16),
(207, ' XF Sportbrake 2.0 D 163 E-Performance BVM Business Sport ', 19),
(208, 'Cee''d SW 1.0i T-GDi 120 Premium Business', 21),
(209, 'Optima SW 2.0 GDi 205 Hybride Rechargeable BVA6 Ultimate Business', 21),
(210, '6 FW 2.2 SkyActiv-D 175 4x4 BVA6 Sélection', 29),
(211, 'E 350 d Break 258ch 4Matic 9G-Tronic Fascination', 31),
(212, 'CLS 350 Shooting Brake 258ch BlueTEC BVA Fascinatio', 31),
(213, 'CLA 200 Shooting Brake 156ch Business Executive Edition', 31),
(214, 'C 350 e Break 211ch 7G-Tronic Fascination', 31),
(215, 'Insignia Country Tourer 2.0 D 170 BlueInjection AWD', 35),
(216, 'Insignia Tourer 1.6 D 136 Ecotec Business Edition Pack', 35),
(217, 'Astra Sports Tourer 1.6 CDTI 136 BVA6 Elite', 35),
(218, '508 RXH 2.0 BlueHDi 180 EAT6', 36),
(219, '508 SW 1.6i THP 165 BVM6 Style', 36),
(220, '308 SW 1.5 BlueHDi 130 BVM6 GT Line', 36),
(221, 'Talisman Estate 1.6i TCe 150 Energy EDC Limited', 39),
(222, 'Laguna Estate 2.0 dCi 175 BVA Intens', 39),
(223, 'Mégane Estate 1.6i TCe 165 Energy EDC Intens', 39),
(224, 'Clio Estate 1.5 dCi 110 Energy Steel', 39),
(225, 'Leon X-Perience 2.0 TDI 150 4Drive', 41),
(226, 'Leon ST 1.6 TDI 115 DSG7 Xcellence', 41),
(227, 'Superb Combi 2.0 TDI 190 Laurin&Klement', 42),
(228, 'Outback Boxer Diesel 2.0D Luxury', 43),
(229, 'Legacy Break Boxer 2.5i CVT Lineartronic Sport Club', 43),
(230, 'Levorg 1.6i Turbo 170 Lineartronic Exclusive', 43),
(231, 'Model X 100D Dual Motor 693 ', 44),
(232, 'Avensis SW 147 VVT-i SkyView ', 46),
(233, 'Avensis Touring Sports 143 D-4D Executive Business ', 46),
(234, 'Auris Touring Sports 1.2T 116 116 Executive', 46),
(235, 'Passat AllTrack 2.0 TDi CR FAP BlueMotion Technology 4Motion', 47),
(236, 'SW 2.0 TDI 150 BlueMotion Technology Série Spéciale Connect', 47),
(237, 'Golf SW 1.5 TSI 130 EVO BlueMotion Connect', 47),
(238, 'V90 2.0 D4 190 Business', 48),
(239, 'V70 1.6i T4 180 Xénium', 48),
(240, 'V60 2.4 5cyl. D6 Twin Engine 220 + 68 Geartronic R-Design ', 48),
(241, '124 Spider 1.4i MultiAir Turbo 170 BVM6', 1),
(242, 'Spider 3.2i V6 JTS 260 Q4 Qtronic', 2),
(243, '4C Spider 1750 Tbi 240 TCT Standard Edition', 2),
(244, '4C 1750 Tbi 240 TCT Standard Edition', 2),
(245, 'B4 3.0d 6cyl Biturbo 350 Switch-Tronic', 3),
(246, 'B5 4.4i V8 BiTurbo 507 Switch-Tronic', 3),
(247, 'GT 3.6i V6 300 DSG 6 GT', 4),
(248, 'Virage Volante 6.0i V12 477 BVA Cabriolet', 5),
(249, 'Virage Coupé 6.0i V12 ', 5),
(250, 'Vantage Coupé 4.8i V8 430 S', 5),
(251, 'Vantage Roadster 4.8i V8 426', 5),
(252, 'DBS Coupé 6.0i V12 517 Touchtronic', 5),
(253, 'TTS Coupé 2.0 TFSI 310 Quattro S tronic 6', 6),
(254, 'TTS Roadster 2.0 TFSI 310 Quattro S tronic 6', 6),
(255, 'TT RS Coupé 2.5 TFSI 400 Quattro S tronic 7', 6),
(256, 'RS Plus Roadster 2.5 TFSI 360 Quattro', 6),
(257, 'S8 4.0 V8 Quattro Tiptronic 8 Sport', 6),
(258, 'S5 3.0 V6 TFSI 354 Quattro Tiptronic 8', 6),
(259, 'S5 Cabriolet 3.0 V6 TFSI 354 Quattro S tronic 8', 6),
(260, 'S3 Cabriolet 2.0 TFSI 310 Quattro S tronic 7 ', 6),
(261, 'S3 2.0 TFSI 300 Quattro S tronic 6 ', 6),
(262, 'RS5 2.9 V6 TFSI 450 Quattro Tiptronic 8', 6),
(263, 'RS5 Cabriolet 4.2 V8 FSI 450 Quattro S tronic 7', 6),
(264, 'A5 Cabriolet 2.0 TFSI 190 Avus', 6),
(265, 'A3 Cabriolet 2.0 TDI 150 Quattro Design Luxe', 6),
(266, 'Azure Cabriolet 6.8i V8 457 BVA ', 7),
(267, 'i8 Coupé 1.5i TwinPower Turbo Hybride Coupé 362ch BVA6 Protonic Red Edition', 8),
(268, 'Z4 Roadster sDrive35i Roadster 306ch M Sport', 8),
(269, 'M6 Gran Coupé 4.4i V8 BiTurbo Gran Coupé 600ch DKG7 Pack Compétition M ', 8),
(270, 'M6 Coupé 4.4i V8 Coupé 560ch DKG7 ', 8),
(271, 'M6 Cabriolet 4.4i V8 Cabriolet 560ch DKG7', 8),
(272, 'M5 4.4i V8 M TwinPower Biturbo 600ch BVA8', 8),
(273, 'M4 Cabriolet 3.0 M TwinPower Turbo Cabriolet 450ch Pack Competition', 8),
(274, 'M4 Coupé 3.0 M TwinPower Turbo Coupé 431ch', 8),
(275, 'M2 Coupé 3.0i Coupé 370ch', 8),
(276, 'Série 6 640d 313ch BVA Lounge Plus', 8),
(277, 'Série 6 Cabriolet 640d Cabriolet 313ch BVA Exclusive', 8),
(278, 'Série 6 Gran Coupé 650i xDrive Gran Coupé 450ch BVA Exclusive', 8),
(279, 'Série 4 Cabriolet 420d Cabriolet 190ch M Sport', 8),
(280, 'Série 4 Coupé 440i Coupé 326ch Luxury', 8),
(281, 'Série 4 Gran Coupé 420d xDrive Gran Coupé 190ch Business', 8),
(282, 'Série 3 Cabriolet 330d Cabriolet 245ch Exclusive', 8),
(283, 'Série 2 Cabriolet M240i xDrive Cabriolet', 8),
(284, 'Série 2 Coupé 230i Coupé Luxury', 8),
(285, 'Corvette 6.2i V8 437 ZR1', 9),
(286, 'Corvette Cabriolet 6.2i V8 437 Grand Sport ', 9),
(287, 'Camaro Cabriolet 6.2i V8', 9),
(288, 'Camaro Cabriolet 6.2i V8', 9),
(289, 'DS4 CrossBack 1.6i THP 165 EAT6 Edition Limitée Terre Roug', 11),
(290, 'DS3 Cabriolet 1.6 BlueHDi 100 BVM Givenchy Le MakeUp ', 11),
(291, 'F430 Spider 4.3i V8 Cabriloet', 12),
(292, 'F430 4.3i V8', 12),
(293, 'California Convertible 4.3i V8 Cabriolet', 12),
(294, '612 Scaglietti 5.8i V12 540 BVA F1 One to One', 12),
(295, '458 Italia 4.5i V8', 12),
(296, '458 Spider 4.5i V8 ', 12),
(297, '16M Scuderia Spider 4.3i V8', 12),
(298, 'Karma Hybrid 212 BVA Ecochic ', 13),
(299, 'Mustang Convertible 5.0i V8 421 GT', 14),
(300, 'Mustang Fastback 5.0i V8 421 Black Shadow Edition', 14),
(301, 'Honda NSX 3.5 V6 i-VTEC', 15),
(302, 'Civic Type R 2.0 i-VTEC 310 GT', 15),
(303, 'G37 Cabriolet 3.7 V6 BVA GT Premium', 17),
(304, 'Q60 Coupé S V6 3.0t AWD BVA Sport Tech', 17),
(305, 'Q60 Cabriolet 60 3.7 V6 BVA GT Premium', 17),
(306, 'F-Type Cabriolet 3.0i V6 Suralimenté 380 R-Dynamic', 19),
(307, 'F-Type Coupé 3.0i V6 Suralimenté', 19),
(308, 'XKR Cabriolet 5.0i V8 Suralimenté', 19),
(309, 'Kia Pro_Cee''d GT 1.6 T-GDi 204 GT', 21),
(310, 'Gallardo 5.2i V10 570 Super Trofeo Stradale ', 24),
(311, 'Gallardo Spyder 5.2i V10 LP 570-4 e-Gear Performante Edizione Tecnica', 24),
(312, 'Gallardo Superleggera 5.2i V10 LP 570-4 e-Gear Edizione Tecnica', 24),
(313, 'Murcielago 6.5i V12 670 e-Gear SV', 24),
(314, 'Murcielago Roadster 6.5i V12 650 e-Gear', 24),
(315, 'RC F 300h 2.5i 181 e-CVT F Sport Executive', 25),
(316, 'LC 500 5.0i V8 477 BVA Blue Edition', 25),
(317, 'Elise 1.8i 250 Cup 250', 26),
(318, 'Evora 3.5i V6 400 BVA 2+2', 26),
(319, 'Evora 3.5i V6 400 BVA 2+2', 26),
(320, 'Ghibli 3.0 V6 430 BVA S Q4 GranSport', 27),
(321, 'Grancabrio Cabriolet 4.7i V8 460 BVA MC Centennial Edition', 27),
(322, 'Granturismo 4.7i V8 460 BVA MC Stradale Centennial Edition ', 27),
(323, 'MXT 2.0 250', 28),
(324, 'MX-5 Roadster 2.0i SkyActiv-G 160 SkyActive Sélection', 29),
(325, '540C V8 3.8i 540 BVA', 30),
(326, '570 GT V8 3.8i 570 BVA', 30),
(327, '570 S V8 3.8i 570 BVA', 30),
(328, '570 S Spider V8 3.8 570 BVA', 30),
(329, '650S V8 3.8i 650 BVA', 30),
(330, '650S Spider V8 3.8i 650 BVA Can-Am', 30),
(331, '675LT Spider V8 3.8i 675 BVA', 30),
(332, '720S V8 3.8i 720 BVA Performance', 30),
(333, 'GLE Coupé GLE 63 S AMG Coupé 4-Matic BVA', 31),
(334, ' SLK 250 d 204ch BVA', 31),
(335, 'SLS AMG 571ch BVA', 31),
(336, 'SLS AMG Roadster 591ch BVA GT (Cabriolet)', 31),
(337, 'SLC 250 d 204ch 9G-Tronic Fascination', 31),
(338, 'SL 500 455ch 9G-Tronic Executive ', 31),
(339, 'AMG-GT 462ch Speedshift DCT 7', 31),
(340, 'S 500 Cabriolet', 31),
(341, 'S 500 Coupé 455ch 4Matic BVA Edition', 31),
(342, 'E 220 d Cabriolet 194ch 4-Matic 9G-Tronic Fascination ', 31),
(343, ' E 220 d Coupé 194ch 9G-Tronic Fascination', 31),
(344, 'C 43 AMG Cabriolet 367ch 4-Matic 9G-Tronic', 31),
(345, 'C 63 AMG Coupé 476ch 7G-Tronic +', 31),
(346, '370Z Coupé 3.7i V6 328 BVA Pack', 34),
(347, '370Z Roadster 3.7i V6 328 Pack ', 34),
(348, 'GT-R 3.8i V6 570 BVA Track Edition', 34),
(349, 'Cascada 2.0 CDTI 170 BlueInjection Elite', 35),
(350, 'Astra GTC 2.0 CDTI 165 FAP BVA Sport Pack', 35),
(351, 'RCZ 2.0 HDi 160 FAP Red Carbon', 36),
(352, 'Cevennes 1.6', 37),
(353, 'Hemera 1.61', 37),
(354, 'Speedster 1.6', 37),
(355, 'Cayman 3.8i 385 GT4', 38),
(356, 'Porsche Boxster Spyder 3.8i 375', 38),
(357, 'Boxster 3.4i 330 GTS', 38),
(358, '911 3.8i 430 PDK Carrera GTS', 38),
(359, '911 Cabriolet 3.0i 420 PDK Carrera 4S', 38),
(360, '911 Carrera T 3.0i', 38),
(361, '911 GT3 4.0i 500 PDK RS', 38),
(362, '911 Targa 3.4i 350 4', 38),
(363, '911 Turbo 3.8i Turbo 580 PDK S', 38),
(364, '911 Turbo Cabriolet 3.8i Turbo 580 PDK S ', 38),
(365, '718 Boxster 2.5i GTS 365 PDK', 38),
(366, '718 Cayman 2.5i GTS 365', 38),
(367, 'Panamera 3.0i V6 416 Hybrid Tiptronic S S', 38),
(368, 'Panamera Sport Turismo 4.0D V8 422 PDK 4S', 38),
(369, 'Renault Laguna 2.0 dCi 175 BVA Intens', 39),
(370, 'Mégane CC 1.6 dCi 130 FAP Energy GT Line', 39),
(371, 'Mégane Coupé 1.6 dCi 130 Euro 6 Bose', 39),
(372, 'Clio 1.6i Turbo 220 Energy EDC RS Trophy ', 39),
(373, 'Phantom Coupé 6.8i V12 460 BVA', 40),
(374, 'Leon SC 2.0 TSI 300 DSG6 Cupra', 41),
(375, 'WRX STi 2.5T 300 S Club Aileron', 43),
(376, 'BRZ Coupé 2.0 200 BVA Club', 43),
(377, 'GT86 2.0L Coupé BVA Blue Racing', 46),
(378, 'Cabriolet 2.0 TSI 220 BlueMotion Technology DSG6 GTI', 47),
(379, 'Golf 2.0 TSI 310 BlueMotion Technology 4Motion DSG7 R', 47),
(380, 'Volkswagen Scirocco 2.0 TSI 180 DSG6 Série Limitée Ultimate', 47),
(381, '8C Spider 4.7i V8 450 BVA ', 2),
(382, 'Vantage Roadster 4.8i V8 426', 5),
(383, 'Vanquish S 6.0i V12 600 Touchtronic 3', 5),
(384, 'DBS Volante 6.0i V12 Cabriolet', 5),
(385, 'DB9 Coupé 6.0i V12 510 BVA Coupé Touchtronic II ', 5),
(386, 'DB9 Volante 6.0i V12 510 Touchtronic II  Cabriolet', 5),
(387, 'DB11 5.2i V12 Biturbo ', 5),
(388, 'Rapide 6.0i V12 560 Touchtronic III S', 5),
(389, 'S8 4.0 V8 Quattro Tiptronic 8 Sport', 6),
(390, 'R8 5.2 V10 Plus FSI 610 Quattro S tronic 7 ', 6),
(391, 'R8 5.2 V10 Plus FSI 610 Quattro S tronic 7', 6),
(392, 'Mulsanne 6.8i V8 512 BVA Extended Wheelbase', 7),
(393, 'Flying Spur 4.0i V8 507 BVA', 7),
(394, 'Continental 6.0i W12 709 BVA Supersports ', 7),
(395, 'Continental Cabriolet 6.0i W12 635 BA8 Speed', 7),
(396, 'Continental GT3-R 4.0i V8 580 BVA BA8', 7),
(397, 'Portofino 4.0i V8', 12),
(398, 'FF 6.0i V12 ', 12),
(399, 'California T 4.0i V8', 12),
(400, '812 SuperFast 6.5i V12 ', 12),
(401, '599 GTB 6.0i V12 620 BVA F1', 12),
(402, '488 GTB 4.0i V8', 12),
(403, '488 Spider 4.0i V8', 12),
(404, '458 Speciale 4.5i V8', 12),
(405, 'LS 500h 3.5i V6 299 4WD BVA Executive', 25),
(406, 'SLR 5.5i V8', 31),
(407, 'SL 65 AMG 630ch 7G-Tronic Speedshift Plus', 31),
(408, 'AMG-GT 585ch Speedshift DCT 7 R', 31),
(409, 'S 65 S AMG Cabriolet 630ch Speedshift Plus AMG', 31),
(410, 'S 65 AMG Coupé ', 31),
(411, 'S 65 AMG L 630ch BVA (Limousine)', 31),
(412, 'CLS 63 AMG 585ch 4-Matic BVA S ', 31),
(413, 'Plus 8 4.8 L V8 BVA Centenaire', 32),
(414, 'V6 Tourer 3.7 L Centenaire', 32),
(415, 'Plus 4 Tourer 2.0 L Centenaire', 32),
(416, '4/4 1.6 L Centenaire', 32),
(417, 'Phantom 6.8i V12 460 BVA EWB', 40),
(418, 'Phantom Convertible 6.8i V12 460 BVA Drophead Cabriolet', 40),
(419, 'Ghost 6.6i V12 570 BVA EWB', 40),
(420, 'Série 2 Gran Tourer 220d Gran Tourer 190ch Business', 8),
(421, 'Série 2 Active Tourer 225e xDrive Active Tourer 224ch iPerformance BVA Lounge', 8),
(422, 'i3 Electrique 94 Ah 184ch BVA iLife Suite', 8),
(423, 'SpaceTourer XL 2.0 BlueHDi 180 EAT6 Business', 10),
(424, 'Jumpy Multispace L2H1 2.0 HDi 95 Attraction ', 10),
(425, 'C8 2.0 HDi 160 Millenium', 10),
(426, 'C4 Grand Picasso 2.0 BlueHDi 150 EAT6 Shine', 10),
(427, 'C4 Picasso 2.0 BlueHDi 150 Shine', 10),
(428, 'Grand Tourneo 1.5 D 120 EcoBlue Connect Titanium ', 14),
(429, 'S-Max 2.0 TDCi 150 Intelligent AWD Titanium', 14),
(430, 'S-Max Vignale 2.0 TDCi 180 i-AWD PowerShift', 14),
(431, 'Galaxy 2.0 TDCi 150 i-AWD Titanium', 14),
(432, 'B-Max 1.5 TDCi 95 Color Edition', 14),
(433, 'Grand C-Max 2.0 TDCi 150 Titanium X', 14),
(434, 'C-Max 2.0 TDCi 150 Powershift Titanium X ', 14),
(435, 'Voyager 2.8 D MultiJet II 178 BVA Platinum', 14),
(436, '5 1.8 MZ-CD 115 Dynamique ', 29),
(437, 'Marco Polo 250 d 190ch 7G-Tronic', 31),
(438, 'Marco Polo Activity 220 d Activity ', 31),
(439, 'V 220 d Long ', 31),
(440, 'Evalia 1.5 dCi 110 N-Connecta', 34),
(441, 'e-NV200 Evalia Electrique 109', 34),
(442, 'Zafira Tourer 2.0 CDTI 170 BVA Cosmo Pack', 35),
(443, 'Zafira 1.7 CDTI 125 FAP Connect Pack', 35),
(444, 'Meriva 1.4i Turbo Twinport 120 Drive', 35),
(445, '5008 1.6 BlueHDi 120 BVM6 Active Business ', 36),
(446, '807 2.0 HDi 160 FAP Style', 36),
(447, '5008 2.0 BlueHDi 150 BVM6 Allure', 36),
(448, 'Trafic Passenger L1H1 1000kg 2.0 dCi 115 FAP Euro 5 BVR Executive', 39),
(449, 'Grand Espace 2.0 dCi 175 FAP Initiale', 39),
(450, 'Espace 1.6 dCi Twin Turbo 160 Energy EDC Initiale Paris ', 39),
(451, 'Scénic 1.5 dCi 110 Hybrid Assist Energy Business ', 39),
(452, 'Grand Scénic 1.5 dCi 110 Hybrid Assist Energy Intens', 39),
(453, 'Alhambra 2.0 TDI 150 4Drive Premium 7', 39),
(454, 'Altea 2.0 TDI 140 I Tech', 41),
(455, 'Prius + 136h Hybride 99 BVA Lounge', 46),
(456, 'Verso 112 D-4D FAP Style', 46),
(457, 'Caravelle Longue 2.0 TDI 204 BlueMotion Technology ConfortLine', 47),
(458, 'Sharan 2.0 TDI 184 BlueMotion Technology DSG6 Carat', 47),
(459, 'portsvan 1.4 TSI MultiFuel E85 125 ConfortLine Business', 47);

-- --------------------------------------------------------

--
-- Structure de la table `options`
--

CREATE TABLE IF NOT EXISTS `options` (
  `ID_OPTION` int(11) NOT NULL,
  `NOM_OPTION` varchar(99) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `options`
--

INSERT INTO `options` (`ID_OPTION`, `NOM_OPTION`) VALUES
(1, 'Aide a la conduite'),
(2, 'Boite Automatique'),
(3, 'Climatisation'),
(4, 'GPS'),
(5, 'Siège en cuir'),
(6, 'Toit Panoramique');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE IF NOT EXISTS `utilisateur` (
  `ID_UTILISATEUR` int(11) NOT NULL,
  `NOM_UTILISATEUR` varchar(199) DEFAULT NULL,
  `MOT_PASSE_UTILISATEUR` varchar(199) DEFAULT NULL,
  `ID_GRADE_UTILISATEUR` int(11) NOT NULL,
  `CLE_EMPLOYE` varchar(199) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `utilisateur`
--

INSERT INTO `utilisateur` (`ID_UTILISATEUR`, `NOM_UTILISATEUR`, `MOT_PASSE_UTILISATEUR`, `ID_GRADE_UTILISATEUR`, `CLE_EMPLOYE`) VALUES
(0, 'Julien', 'aaaaaa', 2, 'ZZZ999999999ZZZ'),
(1, 'admin', 'd404559f602eab6fd602ac7680dacbfaadd13630335e951f097af3900e9de176b6db28512f2e000b9d04fba5133e8b1c6e8df59db3a8ab9d60be4b97cc9e81db', 1, 'XXX000000000XXX'),
(2, 'Nicolas', 'df6b9fb15cfdbb7527be5a8a6e39f39e572c8ddb943fbc79a943438e9d3d85ebfc2ccf9e0eccd9346026c0b6876e0e01556fe56f135582c05fbdbb505d46755a', 2, 'XXX123456789XXX'),
(4, 'Coco', 'Azazazel', 1, 'XXX000000002XXX');

-- --------------------------------------------------------

--
-- Structure de la table `voiture`
--

CREATE TABLE IF NOT EXISTS `voiture` (
  `ID_VOITURE` int(11) NOT NULL,
  `PUISSANCE` int(11) NOT NULL,
  `PRIX_ACHAT` int(11) NOT NULL,
  `COTE_ARGUS` int(11) NOT NULL,
  `PHOTO` varchar(199) NOT NULL,
  `NOMBRE_PLACE` int(11) NOT NULL,
  `ID_CARBURANT` int(11) NOT NULL,
  `ID_MODELE` int(11) NOT NULL,
  `ID_COULEUR` int(11) NOT NULL,
  `ID_CATEGORIE` int(11) NOT NULL,
  `ID_ANNEE_FABRICATION` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=461 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `voiture`
--

INSERT INTO `voiture` (`ID_VOITURE`, `PUISSANCE`, `PRIX_ACHAT`, `COTE_ARGUS`, `PHOTO`, `NOMBRE_PLACE`, `ID_CARBURANT`, `ID_MODELE`, `ID_COULEUR`, `ID_CATEGORIE`, `ID_ANNEE_FABRICATION`) VALUES
(1, 210, 44080, 46585, 'AlfaRomeo.png', 5, 1, 1, 6, 1, 2),
(2, 350, 37000, 39627, 'Alpina.png', 5, 1, 2, 2, 1, 4),
(3, 258, 96410, 96410, 'Audi.png', 5, 6, 3, 3, 1, 1),
(4, 190, 51163, 49250, 'Audi.png', 5, 1, 4, 9, 1, 2),
(5, 220, 29700, 28380, 'Audi.png', 5, 3, 5, 13, 1, 3),
(6, 190, 38968, 38220, 'Audi.png', 5, 1, 6, 7, 1, 2),
(7, 608, 117665, 113210, 'Bentley.png', 5, 3, 7, 6, 1, 4),
(8, 258, 60590, 56955, 'BMW.png', 4, 1, 8, 12, 1, 2),
(9, 231, 40110, 38370, 'BMW.png', 5, 1, 9, 3, 1, 4),
(10, 360, 50223, 47360, 'BMW.png', 5, 3, 10, 2, 1, 4),
(11, 150, 53800, 53800, 'BMW.png', 5, 1, 11, 12, 1, 1),
(12, 150, 44700, 44700, 'BMW.png', 5, 1, 12, 9, 1, 1),
(13, 136, 24260, 24260, 'BMW.png', 5, 3, 13, 11, 1, 3),
(14, 130, 17200, 15870, 'Chevrolet.png', 5, 1, 14, 12, 1, 3),
(15, 140, 13600, 13600, 'Chevrolet.png', 7, 3, 15, 8, 1, 4),
(16, 184, 23420, 21165, 'Chevrolet.png', 7, 1, 16, 5, 1, 3),
(17, 200, 24440, 24040, 'Ford.png', 5, 1, 17, 14, 1, 4),
(18, 160, 20900, 20900, 'Ford.png', 2, 1, 18, 9, 1, 2),
(19, 200, 25770, 25770, 'Ford.png', 4, 1, 19, 3, 1, 3),
(20, 210, 40910, 39274, 'Ford.png', 5, 1, 20, 11, 1, 2),
(21, 140, 24850, 24850, 'Ford.png', 5, 3, 21, 6, 1, 1),
(22, 150, 34050, 34050, 'Ford.png', 5, 3, 22, 8, 1, 1),
(23, 136, 40250, 36969, 'Hyundai.png', 5, 2, 23, 9, 1, 2),
(24, 136, 22650, 22650, 'Hyundai.png', 5, 1, 24, 2, 1, 4),
(25, 200, 33310, 33310, 'Hyundai.png', 5, 1, 25, 14, 1, 3),
(26, 120, 21700, 20860, 'Hyundai.png', 5, 3, 26, 2, 1, 2),
(27, 211, 33660, 29621, 'Infinity.png', 5, 3, 27, 3, 1, 2),
(28, 240, 33830, 33830, 'Infinity.png', 5, 1, 28, 14, 1, 3),
(29, 320, 43754, 40350, 'Infinity.png', 5, 3, 29, 6, 1, 3),
(30, 163, 21600, 21600, 'Isuzu.png', 5, 1, 30, 9, 1, 4),
(31, 380, 70690, 66457, 'Jaguar.png', 5, 3, 31, 12, 1, 2),
(32, 240, 64200, 64200, 'Jaguar.png', 5, 1, 32, 6, 1, 1),
(33, 140, 17868, 17660, 'Jeep.png', 5, 3, 33, 2, 1, 4),
(34, 140, 29940, 29341, 'Jeep.png', 5, 1, 34, 11, 1, 2),
(35, 272, 36930, 36930, 'Jeep.png', 5, 3, 35, 7, 1, 3),
(36, 286, 40370, 38553, 'Jeep.png', 5, 4, 36, 13, 1, 3),
(37, 200, 43000, 43000, 'Kia.png', 5, 1, 37, 2, 1, 1),
(38, 136, 26440, 24940, 'Kia.png', 5, 1, 38, 14, 1, 3),
(39, 110, 19857, 19030, 'Kia.png', 5, 1, 39, 6, 1, 2),
(40, 240, 43850, 42450, 'LandRover.png', 5, 3, 40, 11, 1, 3),
(41, 180, 42157, 40740, 'LandRover.png', 4, 1, 41, 14, 1, 4),
(42, 180, 36310, 36310, 'LandRover.png', 4, 1, 42, 2, 1, 4),
(43, 306, 72730, 72730, 'LandRover.png', 5, 6, 43, 9, 1, 2),
(44, 122, 17360, 17360, 'LandRover.png', 2, 1, 44, 13, 1, 4),
(45, 122, 18310, 18310, 'LandRover.png', 2, 1, 45, 12, 1, 4),
(46, 122, 20540, 20540, 'LandRover.png', 6, 1, 46, 13, 1, 4),
(47, 122, 25680, 25680, 'LandRover.png', 7, 1, 47, 9, 1, 4),
(48, 122, 20270, 20271, 'LandRover.png', 6, 1, 48, 6, 1, 4),
(49, 340, 40718, 39730, 'LandRover.png', 5, 3, 49, 3, 1, 3),
(50, 180, 40030, 40030, 'LandRover.png', 5, 1, 50, 14, 1, 2),
(51, 250, 66700, 66700, 'LandRover.png', 5, 3, 51, 2, 1, 1),
(52, 258, 100800, 100800, 'LandRover.png', 5, 1, 52, 8, 1, 1),
(53, 155, 34820, 34820, 'Lexus.png', 5, 6, 53, 6, 1, 4),
(54, 263, 59638, 55050, 'Lexus.png', 5, 6, 54, 9, 1, 2),
(55, 430, 74440, 74440, 'Maserati.png', 5, 3, 55, 9, 1, 2),
(56, 160, 24190, 24190, 'Mazda.png', 5, 3, 56, 12, 1, 3),
(57, 163, 32540, 34114, 'Mercedes.png', 4, 1, 57, 13, 1, 2),
(58, 258, 62283, 59410, 'Mercedes.png', 7, 1, 58, 9, 1, 4),
(59, 258, 77970, 77970, 'Mercedes.png', 5, 3, 59, 3, 1, 3),
(60, 544, 68620, 67705, 'Mercedes.png', 5, 3, 60, 2, 1, 4),
(61, 245, 61420, 61420, 'Mercedes.png', 5, 1, 61, 6, 1, 2),
(62, 170, 31860, 31438, 'Mercedes.png', 5, 1, 62, 2, 1, 4),
(63, 334, 75370, 73693, 'Mercedes.png', 5, 6, 63, 6, 1, 2),
(64, 258, 59240, 56081, 'Mercedes.png', 5, 1, 64, 12, 1, 4),
(65, 211, 49180, 51860, 'Mercedes.png', 5, 6, 65, 8, 1, 2),
(66, 211, 52040, 50120, 'Mercedes.png', 5, 6, 66, 7, 1, 3),
(67, 211, 32340, 32340, 'Mercedes.png', 5, 3, 67, 14, 1, 3),
(68, 136, 14360, 13360, 'Mitsubishi.png', 2, 1, 68, 6, 1, 5),
(69, 181, 32690, 32690, 'Mitsubishi.png', 2, 1, 69, 9, 1, 1),
(70, 154, 31390, 31390, 'Mitsubishi.png', 5, 1, 70, 11, 1, 1),
(71, 163, 32990, 32990, 'Mitsubishi.png', 5, 3, 71, 12, 1, 1),
(72, 120, 50900, 50900, 'Mitsubishi.png', 5, 6, 72, 6, 1, 1),
(73, 190, 41390, 41390, 'Mitsubishi.png', 5, 1, 73, 9, 1, 1),
(74, 190, 54590, 549590, 'Mitsubishi.png', 7, 1, 74, 2, 1, 1),
(75, 117, 20150, 18151, 'Mitsubishi.png', 5, 3, 75, 4, 1, 3),
(76, 190, 29420, 29420, 'Nissan.png', 5, 1, 76, 2, 1, 2),
(77, 231, 28440, 28440, 'Nissan.png', 5, 1, 77, 8, 1, 4),
(78, 231, 36240, 35163, 'Nissan.png', 5, 3, 78, 6, 1, 3),
(79, 190, 19090, 18572, 'Nissan.png', 2, 1, 79, 9, 1, 4),
(80, 255, 28810, 27895, 'Nissan.png', 5, 3, 80, 2, 1, 3),
(81, 177, 28160, 28160, 'Nissan.png', 7, 1, 81, 11, 1, 2),
(82, 130, 38050, 38050, 'Nissan.png', 5, 1, 82, 2, 1, 1),
(83, 218, 16070, 16635, 'Nissan.png', 5, 3, 83, 9, 1, 4),
(84, 177, 39850, 39850, 'Opel.png', 5, 1, 84, 3, 1, 1),
(85, 140, 19340, 18953, 'Opel.png', 5, 5, 85, 6, 1, 2),
(86, 102, 24400, 24400, 'Opel.png', 5, 1, 86, 5, 1, 1),
(87, 333, 64140, 61254, 'Porsche.png', 5, 6, 87, 7, 1, 3),
(88, 360, 61730, 61730, 'Porsche.png', 5, 3, 88, 9, 1, 2),
(89, 129, 15560, 14385, 'Suzuki.png', 5, 1, 89, 6, 1, 4),
(90, 120, 22020, 22020, 'Suzuki.png', 5, 1, 90, 15, 1, 2),
(91, 140, 17390, 17582, 'Suzuki.png', 5, 3, 91, 13, 1, 3),
(92, 120, 14200, 14200, 'Suzuki.png', 5, 1, 92, 2, 1, 4),
(93, 240, 27940, 27940, 'Subaru.png', 5, 3, 93, 13, 1, 3),
(94, 150, 27500, 30121, 'Toyota.png', 5, 1, 94, 9, 1, 2),
(95, 177, 33890, 33890, 'Toyota.png', 5, 1, 95, 6, 1, 3),
(96, 98, 29880, 31920, 'Toyota.png', 5, 6, 96, 9, 1, 2),
(97, 197, 26330, 28758, 'Toyota.png', 5, 6, 97, 2, 1, 4),
(98, 150, 33520, 33520, 'Volkswagen.png', 5, 3, 98, 3, 1, 1),
(99, 150, 44900, 44900, 'Volkswagen.png', 7, 1, 99, 5, 1, 1),
(100, 204, 37060, 40423, 'Volkswagen.png', 5, 1, 100, 8, 1, 2),
(101, 156, 43050, 43050, 'Volvo.png', 5, 3, 101, 9, 1, 1),
(102, 320, 59940, 62223, 'Volvo.png', 5, 6, 102, 15, 1, 2),
(103, 210, 40540, 40540, 'AlfaRomeo.png', 5, 1, 103, 3, 2, 2),
(104, 200, 11670, 11402, 'AlfaRomeo.png', 5, 3, 104, 13, 2, 6),
(105, 175, 18960, 19910, 'AlfaRomeo.png', 5, 1, 105, 6, 2, 3),
(106, 450, 70350, 70350, 'Audi.png', 5, 3, 106, 12, 2, 2),
(107, 354, 49540, 51655, 'Audi.png', 4, 3, 107, 3, 2, 3),
(108, 310, 41350, 39875, 'Audi.png', 5, 3, 108, 9, 2, 2),
(109, 605, 93810, 93810, 'Audi.png', 4, 3, 109, 12, 2, 2),
(110, 400, 52530, 51479, 'Audi.png', 5, 3, 110, 7, 2, 2),
(111, 286, 88110, 96133, 'Audi.png', 4, 1, 111, 4, 2, 2),
(112, 320, 52420, 52420, 'Audi.png', 4, 1, 112, 6, 2, 3),
(113, 150, 26460, 26460, 'Audi.png', 5, 1, 113, 3, 2, 4),
(114, 190, 40390, 40390, 'Audi.png', 4, 1, 114, 2, 2, 3),
(115, 190, 44320, 44320, 'Audi.png', 4, 1, 115, 3, 2, 2),
(116, 190, 24980, 25565, 'Audi.png', 5, 1, 116, 7, 2, 4),
(117, 326, 65280, 65280, 'BMW.png', 5, 6, 117, 2, 2, 3),
(118, 450, 54520, 54520, 'BMW.png', 5, 3, 118, 9, 2, 4),
(119, 320, 62680, 68360, 'BMW.png', 5, 1, 119, 2, 2, 2),
(120, 252, 50570, 46524, 'BMW.png', 5, 3, 120, 8, 2, 2),
(121, 313, 30970, 30970, 'BMW.png', 5, 1, 121, 14, 2, 5),
(122, 190, 41170, 40347, 'BMW.png', 5, 1, 122, 10, 2, 2),
(123, 190, 43830, 42953, 'BMW.png', 5, 1, 123, 13, 2, 2),
(124, 163, 22810, 22202, 'Citroën.png', 5, 6, 124, 6, 2, 4),
(125, 240, 16720, 16403, 'Citroën.png', 5, 1, 125, 9, 2, 6),
(126, 150, 17980, 16990, 'Citroën.png', 5, 1, 126, 1, 2, 4),
(127, 163, 32790, 30823, 'DS.png', 5, 6, 127, 14, 2, 2),
(128, 150, 25390, 25390, 'Ford.png', 5, 1, 128, 4, 2, 2),
(129, 140, 22830, 22830, 'Ford.png', 5, 6, 129, 12, 2, 3),
(130, 180, 29040, 25555, 'Ford.png', 5, 1, 130, 8, 2, 2),
(131, 315, 33860, 33860, 'Hyundai.png', 5, 3, 131, 7, 2, 4),
(132, 120, 26300, 26300, 'Hyundai.png', 5, 2, 132, 2, 2, 2),
(133, 141, 25200, 22176, 'Hyundai.png', 5, 1, 133, 6, 2, 2),
(134, 306, 35760, 35760, 'Infinity.png', 5, 6, 134, 12, 2, 3),
(135, 306, 44840, 44840, 'Infinity.png', 5, 6, 135, 9, 2, 2),
(136, 300, 58530, 58530, 'Jaguar.png', 5, 1, 136, 9, 2, 3),
(137, 380, 64560, 64560, 'Jaguar.png', 5, 3, 137, 2, 2, 2),
(138, 180, 28830, 28830, 'Jaguar.png', 5, 1, 138, 4, 2, 3),
(139, 120, 20690, 20690, 'Kia.png', 5, 3, 139, 13, 2, 1),
(140, 156, 45990, 45900, 'Kia.png', 5, 6, 140, 2, 2, 1),
(141, 200, 38100, 42000, 'Kia.png', 5, 1, 141, 12, 2, 2),
(142, 239, 20870, 19305, 'Lancia.png', 5, 1, 142, 3, 2, 5),
(143, 99, 32730, 34607, 'Lexus.png', 5, 6, 143, 2, 2, 2),
(144, 223, 37990, 39197, 'Lexus.png', 5, 6, 144, 12, 2, 3),
(145, 292, 45980, 46548, 'Lexus.png', 5, 6, 145, 6, 2, 3),
(146, 275, 73130, 72033, 'Maserati.png', 5, 1, 146, 3, 2, 3),
(147, 275, 44250, 44250, 'Maserati.png', 5, 1, 147, 12, 2, 4),
(148, 175, 30940, 30940, 'Mazda.png', 5, 1, 148, 4, 2, 2),
(149, 150, 21980, 22231, 'Mazda.png', 5, 1, 149, 3, 2, 3),
(150, 306, 53590, 53590, 'Mercedes.png', 5, 6, 150, 6, 2, 4),
(151, 333, 61410, 58954, 'Mercedes.png', 5, 6, 151, 9, 2, 4),
(152, 184, 38410, 38410, 'Mercedes.png', 5, 3, 152, 2, 2, 3),
(153, 258, 52490, 52490, 'Mercedes.png', 4, 1, 153, 6, 2, 3),
(154, 136, 32410, 32410, 'Mercedes.png', 5, 1, 154, 12, 2, 2),
(155, 211, 44920, 44920, 'Mercedes.png', 5, 6, 155, 2, 2, 2),
(156, 110, 13660, 14112, 'Nissan.png', 5, 1, 156, 14, 2, 3),
(157, 150, 38900, 38900, 'Nissan.png', 5, 2, 157, 15, 2, 1),
(158, 170, 15490, 15490, 'Opel.png', 5, 3, 158, 12, 2, 4),
(159, 136, 19570, 19179, 'Opel.png', 5, 1, 159, 3, 2, 2),
(160, 170, 25280, 25280, 'Opel.png', 5, 1, 160, 3, 2, 2),
(161, 86, 18820, 18820, 'Opel.png', 4, 6, 161, 13, 2, 4),
(162, 163, 22670, 22670, 'Peugeot.png', 5, 6, 162, 4, 2, 3),
(163, 130, 22460, 22460, 'Renault.png', 5, 1, 163, 6, 2, 3),
(164, 150, 16060, 1552, 'Renault.png', 5, 1, 164, 3, 2, 4),
(165, 175, 15300, 15300, 'Renault.png', 5, 1, 165, 9, 2, 4),
(166, 130, 13910, 13910, 'Renault.png', 5, 3, 166, 9, 2, 3),
(167, 110, 22665, 22665, 'Seat.png', 5, 3, 167, 4, 2, 1),
(168, 300, 31310, 34926, 'Seat.png', 5, 3, 168, 7, 2, 2),
(169, 115, 21270, 21270, 'Seat.png', 5, 1, 169, 9, 2, 1),
(170, 280, 36380, 36380, 'Skoda.png', 5, 3, 170, 2, 2, 2),
(171, 116, 13790, 13790, 'Skoda.png', 5, 1, 171, 12, 2, 3),
(172, 150, 17690, 16340, 'Subaru.png', 5, 1, 172, 8, 2, 4),
(173, 150, 19960, 20813, 'Subaru.png', 5, 3, 173, 11, 2, 3),
(174, 700, 116730, 109726, 'Tesla.png', 5, 2, 174, 12, 2, 2),
(175, 143, 22400, 22400, 'Toyota.png', 5, 1, 175, 9, 2, 2),
(176, 98, 18750, 19328, 'Toyota.png', 5, 6, 176, 3, 2, 3),
(177, 245, 34540, 33323, 'Volkswagen.png', 5, 1, 177, 9, 2, 4),
(178, 150, 50040, 50400, 'Volkswagen.png', 5, 1, 178, 11, 2, 1),
(179, 156, 36950, 36950, 'Volkswagen.png', 5, 6, 179, 14, 2, 2),
(180, 150, 25830, 25830, 'Volkswagen.png', 5, 3, 180, 6, 2, 3),
(181, 150, 17210, 17210, 'Volkswagen.png', 5, 6, 181, 8, 2, 4),
(182, 125, 20690, 19449, 'Volkswagen.png', 5, 4, 182, 7, 2, 2),
(183, 136, 39560, 39560, 'Volkswagen.png', 5, 2, 183, 3, 2, 1),
(184, 320, 63390, 59587, 'Volvo.png', 5, 6, 184, 6, 2, 2),
(185, 181, 20810, 19457, 'Volvo.png', 5, 1, 185, 9, 2, 4),
(186, 152, 20420, 20420, 'Volvo.png', 5, 3, 186, 4, 2, 3),
(187, 420, 43340, 42340, 'Audi.png', 5, 3, 187, 3, 3, 5),
(188, 310, 44300, 44300, 'Audi.png', 5, 3, 188, 6, 3, 2),
(189, 605, 79610, 79610, 'Audi.png', 5, 3, 189, 12, 3, 3),
(190, 450, 73230, 79487, 'Audi.png', 5, 3, 190, 6, 3, 2),
(191, 400, 51980, 50940, 'Audi.png', 5, 3, 191, 2, 3, 2),
(192, 218, 55840, 58620, 'Audi.png', 5, 1, 192, 9, 3, 2),
(193, 190, 31230, 29825, 'Audi.png', 5, 1, 193, 13, 3, 3),
(194, 272, 43820, 41191, 'Audi.png', 5, 1, 194, 5, 3, 3),
(195, 190, 33500, 33500, 'Audi.png', 5, 1, 195, 7, 3, 3),
(196, 150, 36620, 36620, 'Audi.png', 5, 6, 196, 12, 3, 2),
(197, 150, 28530, 28530, 'Audi.png', 5, 1, 197, 3, 3, 3),
(198, 190, 46240, 46616, 'BMW.png', 5, 1, 198, 6, 3, 2),
(199, 190, 33260, 32595, 'BMW.png', 5, 1, 199, 12, 3, 2),
(200, 150, 17540, 17540, 'Citroën.png', 5, 1, 200, 2, 3, 4),
(201, 180, 21910, 21910, 'Citroën.png', 5, 1, 201, 9, 3, 3),
(202, 160, 17070, 17070, 'Ford.png', 5, 3, 202, 3, 3, 4),
(203, 150, 30880, 27174, 'Ford.png', 5, 1, 203, 6, 3, 2),
(204, 120, 17110, 17930, 'Honda.png', 5, 1, 204, 12, 3, 3),
(205, 136, 21990, 20231, 'Hyundai.png', 5, 1, 205, 14, 3, 2),
(206, 141, 25580, 23305, 'Hyundai.png', 5, 1, 206, 3, 3, 2),
(207, 163, 39510, 39510, 'Jaguar.png', 5, 1, 207, 2, 3, 2),
(208, 120, 16950, 16950, 'Kia.png', 5, 3, 208, 13, 3, 2),
(209, 156, 47490, 47490, 'Kia.png', 5, 6, 209, 9, 3, 1),
(210, 175, 27170, 27591, 'Mazda.png', 5, 1, 210, 12, 3, 3),
(211, 258, 59090, 59090, 'Mercedes.png', 5, 1, 211, 12, 3, 2),
(212, 258, 37140, 37722, 'Mercedes.png', 5, 1, 212, 3, 3, 5),
(213, 156, 31650, 31017, 'Mercedes.png', 5, 3, 213, 14, 3, 2),
(214, 211, 39300, 39300, 'Mercedes.png', 5, 6, 214, 13, 3, 3),
(215, 170, 26930, 26930, 'Opel.png', 5, 1, 215, 14, 3, 2),
(216, 136, 22590, 22950, 'Opel.png', 5, 1, 216, 9, 3, 2),
(217, 136, 17030, 18363, 'Opel.png', 5, 1, 217, 1, 3, 3),
(218, 180, 18964, 19382, 'Peugeot.png', 5, 1, 218, 12, 3, 5),
(219, 165, 17660, 17130, 'Peugeot.png', 5, 3, 219, 8, 3, 3),
(220, 130, 32050, 32050, 'Peugeot.png', 5, 1, 220, 3, 3, 1),
(221, 150, 23680, 25450, 'Renault.png', 5, 3, 221, 2, 3, 2),
(222, 175, 15440, 15440, 'Renault.png', 5, 1, 222, 3, 3, 4),
(223, 165, 21780, 23960, 'Renault.png', 5, 3, 223, 9, 3, 2),
(224, 110, 18310, 19417, 'Renault.png', 5, 1, 224, 10, 3, 2),
(225, 150, 21380, 22075, 'Seat.png', 5, 1, 225, 8, 3, 3),
(226, 115, 31355, 31355, 'Seat.png', 5, 1, 226, 12, 3, 1),
(227, 190, 32330, 32330, 'Skoda.png', 5, 1, 227, 8, 3, 2),
(228, 150, 27640, 27640, 'Subaru.png', 5, 1, 228, 6, 3, 3),
(229, 167, 17690, 16555, 'Subaru.png', 5, 3, 229, 9, 3, 4),
(230, 170, 30750, 30750, 'Subaru.png', 5, 3, 230, 3, 3, 2),
(231, 603, 86960, 76525, 'Tesla.png', 7, 2, 231, 2, 3, 2),
(232, 147, 14390, 14390, 'Toyota.png', 5, 3, 232, 3, 3, 4),
(233, 143, 17530, 18707, 'Toyota.png', 5, 1, 233, 6, 3, 3),
(234, 116, 14200, 14200, 'Toyota.png', 5, 3, 234, 2, 3, 4),
(235, 140, 17230, 17230, 'Volkswagen.png', 5, 1, 235, 9, 3, 5),
(236, 150, 26330, 26330, 'Volkswagen.png', 5, 1, 236, 15, 3, 2),
(237, 130, 27380, 27380, 'Volkswagen.png', 5, 3, 237, 6, 3, 1),
(238, 190, 38130, 39130, 'Volvo.png', 5, 1, 238, 2, 3, 2),
(239, 180, 23240, 21240, 'Volvo.png', 5, 3, 239, 6, 3, 4),
(240, 220, 33740, 33740, 'Volvo.png', 5, 6, 240, 9, 3, 3),
(241, 170, 29600, 30460, 'Abarth.png', 2, 3, 241, 2, 4, 3),
(242, 260, 12380, 12293, 'AlfaRomeo.png', 2, 3, 242, 13, 4, 9),
(243, 240, 47450, 47450, 'AlfaRomeo.png', 2, 3, 243, 12, 4, 4),
(244, 240, 30570, 30570, 'AlfaRomeo.png', 2, 3, 244, 7, 4, 5),
(245, 350, 42780, 42780, 'Alpina.png', 4, 1, 245, 3, 4, 2),
(246, 507, 36490, 36490, 'Alpina.png', 5, 3, 246, 2, 4, 6),
(247, 300, 35910, 34850, 'Artega.png', 2, 3, 247, 11, 4, 7),
(248, 477, 100110, 100110, 'AstonMartin.png', 2, 3, 248, 6, 4, 5),
(249, 477, 83180, 83180, 'AstonMartin.png', 2, 3, 249, 11, 4, 6),
(250, 420, 66170, 66170, 'AstonMartin.png', 2, 3, 250, 7, 4, 4),
(251, 426, 39880, 39880, 'AstonMartin.png', 2, 3, 251, 9, 4, 8),
(252, 517, 64350, 64350, 'AstonMartin.png', 2, 3, 252, 13, 4, 10),
(253, 310, 36700, 36700, 'Audi.png', 4, 3, 253, 7, 4, 4),
(254, 310, 43790, 43970, 'Audi.png', 2, 3, 254, 13, 4, 3),
(255, 400, 59380, 58192, 'Audi.png', 4, 3, 255, 12, 4, 2),
(256, 360, 31940, 31623, 'Audi.png', 2, 3, 256, 3, 4, 5),
(257, 450, 61830, 61830, 'Audi.png', 4, 3, 257, 6, 4, 3),
(258, 354, 57310, 57310, 'Audi.png', 4, 3, 258, 9, 4, 2),
(259, 354, 62690, 62690, 'Audi.png', 4, 3, 259, 3, 4, 2),
(260, 310, 48060, 48060, 'Audi.png', 4, 3, 260, 7, 4, 2),
(261, 300, 32270, 32270, 'Audi.png', 5, 3, 261, 12, 4, 4),
(262, 450, 75290, 70773, 'Audi.png', 4, 3, 262, 6, 4, 2),
(263, 450, 54250, 53481, 'Audi.png', 4, 3, 263, 2, 4, 4),
(264, 190, 49310, 44379, 'Audi.png', 4, 3, 264, 9, 4, 2),
(265, 150, 31830, 31830, 'Audi.png', 4, 1, 265, 9, 4, 3),
(266, 457, 71470, 71470, 'Bentley.png', 4, 3, 266, 6, 4, 10),
(267, 362, 101900, 101900, 'BMW.png', 4, 6, 267, 3, 4, 3),
(268, 306, 31950, 31046, 'BMW.png', 2, 3, 268, 2, 4, 5),
(269, 600, 77000, 77000, 'BMW.png', 5, 3, 269, 9, 4, 4),
(270, 560, 80740, 80740, 'BMW.png', 4, 3, 270, 11, 4, 3),
(271, 560, 106790, 106790, 'BMW.png', 4, 3, 271, 7, 4, 2),
(272, 600, 85970, 92725, 'BMW.png', 5, 3, 272, 4, 4, 2),
(273, 450, 77030, 70868, 'BMW.png', 4, 3, 273, 11, 4, 2),
(274, 431, 72080, 66314, 'BMW.png', 4, 3, 274, 13, 4, 2),
(275, 370, 33400, 35337, 'BMW.png', 4, 3, 275, 5, 4, 4),
(276, 313, 44630, 42250, 'BMW.png', 4, 1, 276, 11, 4, 4),
(277, 313, 66050, 66050, 'BMW.png', 4, 1, 277, 13, 4, 3),
(278, 450, 73170, 73170, 'BMW.png', 5, 3, 278, 14, 4, 3),
(279, 190, 48230, 44372, 'BMW.png', 4, 1, 279, 11, 4, 2),
(280, 326, 51200, 47104, 'BMW.png', 4, 3, 280, 15, 4, 2),
(281, 190, 38130, 35080, 'BMW.png', 5, 1, 281, 6, 4, 2),
(282, 245, 24990, 24990, 'BMW.png', 4, 1, 282, 1, 4, 6),
(283, 340, 51690, 50656, 'BMW.png', 4, 3, 283, 9, 4, 2),
(284, 252, 37570, 36819, 'BMW.png', 4, 3, 284, 4, 4, 2),
(285, 647, 76150, 76150, 'Chevrolet.png', 2, 3, 285, 7, 4, 4),
(286, 437, 46880, 46880, 'Chevrolet.png', 2, 3, 286, 13, 4, 4),
(287, 432, 27840, 27840, 'Chevrolet.png', 4, 3, 287, 9, 4, 4),
(288, 432, 21070, 21070, 'Chevrolet.png', 4, 3, 288, 2, 4, 5),
(289, 165, 27880, 27198, 'DS.png', 5, 3, 289, 11, 4, 2),
(290, 99, 21940, 21080, 'DS.png', 5, 1, 290, 14, 4, 2),
(291, 490, 55340, 53495, 'Ferrari.png', 2, 3, 291, 7, 4, 10),
(292, 490, 47970, 46371, 'Ferrari.png', 2, 3, 292, 6, 4, 10),
(293, 490, 97460, 94808, 'Ferrari.png', 4, 3, 293, 12, 4, 5),
(294, 540, 89110, 82431, 'Ferrari.png', 4, 3, 294, 3, 4, 7),
(295, 570, 112090, 112090, 'Ferrari.png', 2, 3, 295, 11, 4, 5),
(296, 570, 98190, 92462, 'Ferrari.png', 2, 3, 296, 7, 4, 7),
(297, 510, 75800, 70747, 'Ferrari.png', 2, 3, 297, 12, 4, 10),
(298, 212, 38630, 38179, 'Fisker.png', 4, 6, 298, 13, 4, 7),
(299, 421, 26960, 26960, 'Ford.png', 4, 3, 299, 6, 4, 4),
(300, 421, 36560, 35098, 'Ford.png', 4, 3, 300, 7, 4, 2),
(301, 500, 132420, 132420, 'Honda.png', 2, 3, 301, 12, 4, 3),
(302, 310, 33340, 33340, 'Honda.png', 5, 3, 302, 6, 4, 2),
(303, 320, 23780, 23780, 'Infinity.png', 4, 3, 303, 3, 4, 6),
(304, 405, 47590, 47950, 'Infinity.png', 4, 3, 304, 4, 4, 2),
(305, 320, 39100, 38478, 'Infinity.png', 4, 3, 305, 6, 4, 3),
(306, 380, 77990, 68631, 'Jaguar.png', 2, 3, 306, 9, 4, 2),
(307, 340, 49750, 49750, 'Jaguar.png', 2, 3, 307, 3, 4, 3),
(308, 510, 45200, 45200, 'Jaguar.png', 4, 3, 308, 6, 4, 6),
(309, 204, 15550, 15550, 'Kia.png', 5, 3, 309, 11, 4, 4),
(310, 570, 102450, 102450, 'Lamborghini.png', 2, 3, 310, 14, 4, 6),
(311, 570, 85370, 87478, 'Lamborghini.png', 2, 3, 311, 7, 4, 7),
(312, 570, 79580, 81123, 'Lamborghini.png', 2, 3, 312, 11, 4, 7),
(313, 670, 113190, 105550, 'Lamborghini.png', 2, 3, 313, 15, 4, 9),
(314, 650, 109550, 102155, 'Lamborghini.png', 2, 3, 314, 13, 4, 9),
(315, 181, 36350, 37997, 'Lexus.png', 4, 6, 315, 3, 4, 4),
(316, 477, 90820, 97192, 'Lexus.png', 4, 3, 316, 2, 4, 2),
(317, 246, 46830, 46830, 'Lotus.png', 2, 3, 317, 15, 4, 2),
(318, 406, 64040, 64040, 'Lotus.png', 4, 3, 318, 13, 4, 3),
(319, 350, 40300, 40300, 'Lotus.png', 2, 3, 319, 6, 4, 4),
(320, 430, 79670, 79670, 'Maserati.png', 5, 3, 320, 12, 4, 2),
(321, 460, 73750, 73750, 'Maserati.png', 4, 3, 321, 9, 4, 5),
(322, 460, 106490, 107468, 'Maserati.png', 4, 3, 322, 3, 4, 4),
(323, 250, 55184, 55184, 'Mastretta.png', 2, 3, 323, 11, 4, 1),
(324, 160, 26890, 25490, 'Mazda.png', 2, 3, 324, 12, 4, 2),
(325, 540, 95410, 91594, 'McLaren.png', 2, 3, 325, 7, 4, 4),
(326, 570, 129990, 120241, 'McLaren.png', 2, 3, 326, 5, 4, 3),
(327, 570, 148790, 148790, 'McLaren.png', 2, 3, 327, 11, 4, 2),
(328, 570, 164160, 160877, 'McLaren.png', 2, 3, 328, 3, 4, 2),
(329, 650, 115180, 109421, 'McLaren.png', 2, 3, 329, 13, 4, 5),
(330, 650, 172060, 178205, 'McLaren.png', 2, 3, 330, 14, 4, 5),
(331, 675, 197300, 208642, 'McLaren.png', 2, 3, 331, 6, 4, 4),
(332, 720, 198200, 182344, 'McLaren.png', 2, 3, 332, 9, 4, 2),
(333, 588, 82210, 77825, 'Mercedes.png', 5, 3, 333, 9, 4, 4),
(334, 204, 44450, 44450, 'Mercedes.png', 5, 1, 334, 12, 4, 1),
(335, 571, 90150, 90150, 'Mercedes.png', 2, 3, 335, 9, 4, 6),
(336, 591, 91480, 91480, 'Mercedes.png', 2, 3, 336, 6, 4, 7),
(337, 204, 40570, 40570, 'Mercedes.png', 2, 1, 337, 6, 4, 3),
(338, 455, 84070, 76504, 'Mercedes.png', 2, 3, 338, 3, 4, 3),
(339, 462, 102520, 102520, 'Mercedes.png', 2, 3, 339, 11, 4, 2),
(340, 455, 77100, 77100, 'Mercedes.png', 4, 3, 340, 3, 4, 4),
(341, 455, 82770, 79638, 'Mercedes.png', 5, 3, 341, 9, 4, 4),
(342, 194, 56500, 61750, 'Mercedes.png', 4, 1, 342, 14, 4, 2),
(343, 194, 46960, 48873, 'Mercedes.png', 4, 1, 343, 3, 4, 3),
(344, 367, 61000, 61000, 'Mercedes.png', 4, 3, 344, 8, 4, 2),
(345, 476, 53640, 53640, 'Mercedes.png', 4, 3, 345, 2, 4, 4),
(346, 328, 27707, 27707, 'Nissan.png', 2, 3, 346, 7, 4, 3),
(347, 328, 21420, 21420, 'Nissan.png', 2, 3, 347, 13, 4, 4),
(348, 570, 93750, 93750, 'Nissan.png', 4, 3, 348, 5, 4, 2),
(349, 170, 39250, 39250, 'Opel.png', 4, 1, 349, 11, 4, 1),
(350, 165, 16610, 16610, 'Opel.png', 5, 3, 350, 12, 4, 4),
(351, 160, 23120, 21410, 'Peugeot.png', 4, 1, 351, 5, 4, 4),
(352, 184, 44750, 44750, 'PGO.png', 2, 3, 352, 9, 4, 1),
(353, 185, 41500, 41500, 'PGO.png', 2, 3, 353, 2, 4, 1),
(354, 184, 44750, 44750, 'PGO.png', 2, 3, 354, 13, 4, 1),
(355, 385, 60050, 57648, 'PGO.png', 2, 3, 355, 5, 4, 4),
(356, 375, 68090, 64955, 'Porsche.png', 2, 3, 356, 2, 4, 2),
(357, 330, 61590, 58975, 'Porsche.png', 2, 3, 357, 1, 4, 2),
(358, 430, 103320, 100470, 'Porsche.png', 4, 3, 358, 9, 4, 3),
(359, 420, 101510, 101510, 'Porsche.png', 4, 3, 359, 6, 4, 3),
(360, 370, 93510, 97636, 'Porsche.png', 4, 3, 360, 3, 4, 2),
(361, 500, 131970, 121412, 'Porsche.png', 2, 3, 361, 13, 4, 2),
(362, 350, 82440, 79803, 'Porsche.png', 4, 3, 362, 7, 4, 3),
(363, 580, 121120, 130253, 'Porsche.png', 4, 3, 363, 11, 4, 4),
(364, 580, 170640, 170640, 'Porsche.png', 4, 3, 364, 12, 4, 2),
(365, 366, 68250, 72226, 'Porsche.png', 2, 3, 365, 9, 4, 2),
(366, 366, 64330, 67955, 'Porsche.png', 2, 3, 366, 11, 4, 3),
(367, 333, 67960, 67960, 'Porsche.png', 4, 6, 367, 2, 4, 4),
(368, 442, 104910, 96517, 'Porsche.png', 4, 1, 368, 7, 4, 2),
(369, 175, 17320, 17320, 'Renault.png', 4, 1, 369, 12, 4, 4),
(370, 130, 15420, 15420, 'Renault.png', 4, 1, 370, 7, 4, 4),
(371, 130, 14930, 14930, 'Renault.png', 5, 1, 371, 9, 4, 3),
(372, 220, 18110, 18110, 'Renault.png', 5, 3, 372, 13, 4, 3),
(373, 460, 244140, 244140, 'RollsRoyce.png', 4, 3, 373, 6, 4, 3),
(374, 300, 29670, 29670, 'Seat.png', 5, 3, 374, 5, 4, 2),
(375, 300, 38690, 38690, 'Subaru.png', 5, 3, 375, 3, 4, 2),
(376, 200, 22880, 22880, 'Subaru.png', 4, 3, 376, 2, 4, 3),
(377, 200, 38200, 38200, 'Toyota.png', 2, 3, 377, 12, 4, 1),
(378, 220, 27670, 26305, 'Volkswagen.png', 4, 3, 378, 12, 4, 3),
(379, 310, 39700, 34936, 'Volkswagen.png', 5, 3, 379, 7, 4, 2),
(380, 180, 27020, 24318, 'Volkswagen.png', 5, 3, 380, 3, 4, 2),
(381, 450, 78050, 78050, 'AlfaRomeo.png', 2, 3, 381, 12, 5, 9),
(382, 576, 168750, 168750, 'AstonMartin.png', 2, 3, 382, 6, 5, 3),
(383, 600, 206680, 181878, 'AstonMartin.png', 2, 3, 383, 11, 5, 2),
(384, 517, 122520, 122520, 'AstonMartin.png', 4, 3, 384, 4, 5, 5),
(385, 510, 94180, 94180, 'AstonMartin.png', 4, 3, 385, 10, 5, 4),
(386, 510, 120400, 120400, 'AstonMartin.png', 4, 3, 386, 15, 5, 3),
(387, 601, 154690, 139647, 'AstonMartin.png', 4, 3, 387, 9, 5, 2),
(388, 560, 147890, 147890, 'AstonMartin.png', 4, 3, 388, 6, 5, 2),
(389, 605, 101560, 101560, 'Audi.png', 5, 3, 389, 9, 5, 2),
(390, 610, 142000, 142000, 'Audi.png', 2, 3, 390, 2, 5, 3),
(391, 610, 159750, 159750, 'Audi.png', 2, 3, 391, 7, 5, 2),
(392, 512, 232620, 232620, 'Bentley.png', 4, 3, 392, 8, 5, 2),
(393, 507, 68630, 68630, 'Bentley.png', 4, 3, 393, 12, 5, 5),
(394, 710, 151740, 165436, 'Bentley.png', 4, 3, 394, 5, 5, 3),
(395, 635, 101850, 10150, 'Bentley.png', 4, 3, 395, 4, 5, 4),
(396, 580, 96730, 96730, 'Bentley.png', 2, 3, 396, 2, 5, 5),
(397, 600, 152020, 162368, 'Ferrari.png', 4, 3, 397, 12, 5, 2),
(398, 660, 192420, 192420, 'Ferrari.png', 4, 3, 398, 7, 5, 3),
(399, 560, 118660, 118660, 'Ferrari.png', 4, 3, 399, 9, 5, 4),
(400, 800, 235580, 216734, 'Ferrari.png', 2, 3, 400, 6, 5, 2),
(401, 620, 123010, 123010, 'Ferrari.png', 2, 3, 401, 2, 5, 7),
(402, 670, 179930, 158338, 'Ferrari.png', 2, 3, 402, 7, 5, 2),
(403, 670, 165000, 165000, 'Ferrari.png', 2, 3, 403, 12, 5, 3),
(404, 605, 186320, 177135, 'Ferrari.png', 2, 3, 404, 14, 5, 3),
(405, 299, 90990, 101993, 'Lexus.png', 4, 6, 405, 6, 5, 2),
(406, 630, 142500, 140583, 'Mercedes.png', 2, 3, 406, 7, 5, 10),
(407, 630, 184710, 184710, 'Mercedes.png', 2, 3, 407, 3, 5, 2),
(408, 585, 140020, 140020, 'Mercedes.png', 2, 3, 408, 9, 5, 2),
(409, 630, 196200, 214900, 'Mercedes.png', 4, 3, 409, 8, 5, 2),
(410, 630, 163450, 163450, 'Mercedes.png', 4, 3, 410, 2, 5, 3),
(411, 630, 162790, 162790, 'Mercedes.png', 5, 3, 411, 13, 5, 2),
(412, 585, 120900, 102900, 'Mercedes.png', 5, 3, 412, 12, 5, 2),
(413, 367, 127000, 127000, 'Morgan.png', 2, 3, 413, 11, 5, 1),
(414, 280, 95000, 95000, 'Morgan.png', 4, 3, 414, 2, 5, 1),
(415, 145, 69500, 69500, 'Morgan.png', 4, 3, 415, 9, 5, 1),
(416, 115, 57000, 57000, 'Morgan.png', 4, 3, 416, 13, 5, 1),
(417, 460, 331210, 331210, 'RollsRoyce.png', 5, 3, 417, 6, 5, 2),
(418, 460, 249040, 249040, 'RollsRoyce.png', 4, 3, 418, 2, 5, 3),
(419, 570, 229890, 229890, 'RollsRoyce.png', 5, 3, 419, 9, 5, 2),
(420, 190, 32680, 30066, 'BMW.png', 7, 1, 420, 4, 6, 2),
(421, 136, 23180, 24257, 'BMW.png', 5, 6, 421, 15, 6, 4),
(422, 184, 38850, 40963, 'BMW.png', 4, 2, 422, 11, 6, 2),
(423, 177, 31950, 30033, 'Citroën.png', 8, 1, 423, 2, 6, 2),
(424, 98, 16217, 16217, 'Citroën.png', 5, 1, 424, 9, 6, 3),
(425, 163, 16080, 16080, 'Citroën.png', 5, 1, 425, 14, 6, 5),
(426, 150, 26090, 26090, 'Citroën.png', 7, 1, 426, 1, 6, 2),
(427, 150, 20200, 20200, 'Citroën.png', 5, 1, 427, 3, 6, 3),
(428, 120, 28790, 28790, 'Ford.png', 5, 1, 428, 2, 6, 1),
(429, 150, 40900, 40900, 'Ford.png', 7, 1, 429, 4, 6, 1),
(430, 180, 50800, 50800, 'Ford.png', 7, 1, 430, 1, 6, 1),
(431, 150, 44250, 44250, 'Ford.png', 7, 1, 431, 14, 6, 1),
(432, 95, 23100, 23100, 'Ford.png', 5, 1, 432, 11, 6, 1),
(433, 150, 33900, 33900, 'Ford.png', 7, 1, 433, 8, 6, 1),
(434, 150, 34300, 34300, 'Ford.png', 5, 1, 434, 4, 6, 1),
(435, 177, 26210, 26210, 'Lancia.png', 7, 1, 435, 2, 6, 4),
(436, 115, 17970, 16790, 'Mazda.png', 7, 1, 436, 12, 6, 3),
(437, 190, 34790, 33398, 'Mercedes.png', 5, 1, 437, 9, 6, 4),
(438, 163, 41250, 41250, 'Mercedes.png', 5, 1, 438, 6, 6, 2),
(439, 163, 56280, 56280, 'Mercedes.png', 6, 1, 439, 2, 6, 2),
(440, 110, 18330, 18330, 'Nissan.png', 7, 1, 440, 13, 6, 2),
(441, 109, 22330, 19650, 'Nissan.png', 7, 2, 441, 10, 6, 2),
(442, 170, 17700, 16284, 'Opel.png', 7, 1, 442, 2, 6, 4),
(443, 125, 11750, 11593, 'Opel.png', 7, 1, 443, 6, 6, 4),
(444, 120, 13550, 13347, 'Opel.png', 5, 5, 444, 11, 6, 3),
(445, 120, 19310, 17862, 'Peugeot.png', 7, 1, 445, 9, 6, 3),
(446, 160, 15980, 15980, 'Peugeot.png', 5, 1, 446, 3, 6, 5),
(447, 150, 21990, 20341, 'Peugeot.png', 7, 1, 447, 2, 6, 3),
(448, 115, 15410, 15273, 'Renault.png', 5, 1, 448, 6, 6, 5),
(449, 175, 23700, 21360, 'Renault.png', 6, 1, 449, 4, 6, 4),
(450, 160, 25350, 23322, 'Renault.png', 5, 1, 450, 3, 6, 4),
(451, 110, 24040, 24040, 'Renault.png', 5, 6, 451, 10, 6, 2),
(452, 110, 25140, 26500, 'Renault.png', 5, 6, 452, 10, 6, 2),
(453, 150, 43845, 43845, 'Seat.png', 7, 1, 453, 2, 6, 1),
(454, 140, 11940, 11940, 'Seat.png', 5, 1, 454, 6, 6, 4),
(455, 99, 29490, 31630, 'Toyota.png', 7, 6, 455, 4, 6, 2),
(456, 112, 18290, 18290, 'Toyota.png', 5, 1, 456, 9, 6, 3),
(457, 204, 28470, 28470, 'Volkswagen.png', 8, 1, 457, 13, 6, 4),
(458, 184, 34740, 34740, 'Volkswagen.png', 7, 1, 458, 3, 6, 2),
(459, 125, 19270, 19270, 'Volkswagen.png', 5, 4, 459, 6, 6, 3),
(460, 1500000, 5111, 150, 'Volvo.png', 1555, 2, 102, 4, 2, 3);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `annee_fabrication`
--
ALTER TABLE `annee_fabrication`
  ADD PRIMARY KEY (`ID_ANNEE_FABRICATION`);

--
-- Index pour la table `carburant`
--
ALTER TABLE `carburant`
  ADD PRIMARY KEY (`ID_CARBURANT`);

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`ID_CATEGORIE`);

--
-- Index pour la table `couleur`
--
ALTER TABLE `couleur`
  ADD PRIMARY KEY (`ID_COULEUR`);

--
-- Index pour la table `disposer`
--
ALTER TABLE `disposer`
  ADD PRIMARY KEY (`ID_OPTION`,`ID_VOITURE`),
  ADD KEY `DISPOSER_Voiture0_FK` (`ID_VOITURE`);

--
-- Index pour la table `employe`
--
ALTER TABLE `employe`
  ADD PRIMARY KEY (`ID_EMPLOYE`),
  ADD UNIQUE KEY `EMPLOYE_AK` (`CLE_EMPLOYE`);

--
-- Index pour la table `grade_utilisateur`
--
ALTER TABLE `grade_utilisateur`
  ADD PRIMARY KEY (`ID_GRADE_UTILISATEUR`);

--
-- Index pour la table `marque`
--
ALTER TABLE `marque`
  ADD PRIMARY KEY (`ID_MARQUE`);

--
-- Index pour la table `modele`
--
ALTER TABLE `modele`
  ADD PRIMARY KEY (`ID_MODELE`),
  ADD KEY `MODELE_marque_FK` (`ID_MARQUE`);

--
-- Index pour la table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`ID_OPTION`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`ID_UTILISATEUR`),
  ADD UNIQUE KEY `CLE_EMPLOYE` (`CLE_EMPLOYE`),
  ADD KEY `utilisateur_grade_utilisateur_FK` (`ID_GRADE_UTILISATEUR`);

--
-- Index pour la table `voiture`
--
ALTER TABLE `voiture`
  ADD PRIMARY KEY (`ID_VOITURE`),
  ADD KEY `Voiture_CARBURANT_FK` (`ID_CARBURANT`),
  ADD KEY `Voiture_MODELE0_FK` (`ID_MODELE`),
  ADD KEY `Voiture_COULEUR1_FK` (`ID_COULEUR`),
  ADD KEY `Voiture_CATEGORIE2_FK` (`ID_CATEGORIE`),
  ADD KEY `Voiture_ANNEE_FABRICATION3_FK` (`ID_ANNEE_FABRICATION`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `annee_fabrication`
--
ALTER TABLE `annee_fabrication`
  MODIFY `ID_ANNEE_FABRICATION` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT pour la table `carburant`
--
ALTER TABLE `carburant`
  MODIFY `ID_CARBURANT` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `ID_CATEGORIE` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT pour la table `couleur`
--
ALTER TABLE `couleur`
  MODIFY `ID_COULEUR` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT pour la table `employe`
--
ALTER TABLE `employe`
  MODIFY `ID_EMPLOYE` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT pour la table `grade_utilisateur`
--
ALTER TABLE `grade_utilisateur`
  MODIFY `ID_GRADE_UTILISATEUR` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `marque`
--
ALTER TABLE `marque`
  MODIFY `ID_MARQUE` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT pour la table `modele`
--
ALTER TABLE `modele`
  MODIFY `ID_MODELE` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=460;
--
-- AUTO_INCREMENT pour la table `options`
--
ALTER TABLE `options`
  MODIFY `ID_OPTION` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `voiture`
--
ALTER TABLE `voiture`
  MODIFY `ID_VOITURE` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=461;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `disposer`
--
ALTER TABLE `disposer`
  ADD CONSTRAINT `DISPOSER_OPTIONS_FK` FOREIGN KEY (`ID_OPTION`) REFERENCES `options` (`ID_OPTION`),
  ADD CONSTRAINT `DISPOSER_Voiture0_FK` FOREIGN KEY (`ID_VOITURE`) REFERENCES `voiture` (`ID_VOITURE`);

--
-- Contraintes pour la table `modele`
--
ALTER TABLE `modele`
  ADD CONSTRAINT `MODELE_marque_FK` FOREIGN KEY (`ID_MARQUE`) REFERENCES `marque` (`ID_MARQUE`);

--
-- Contraintes pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD CONSTRAINT `utilisateur_grade_utilisateur_FK` FOREIGN KEY (`ID_GRADE_UTILISATEUR`) REFERENCES `grade_utilisateur` (`ID_GRADE_UTILISATEUR`);

--
-- Contraintes pour la table `voiture`
--
ALTER TABLE `voiture`
  ADD CONSTRAINT `Voiture_CARBURANT_FK` FOREIGN KEY (`ID_CARBURANT`) REFERENCES `carburant` (`ID_CARBURANT`),
  ADD CONSTRAINT `Voiture_MODELE0_FK` FOREIGN KEY (`ID_MODELE`) REFERENCES `modele` (`ID_MODELE`),
  ADD CONSTRAINT `Voiture_COULEUR1_FK` FOREIGN KEY (`ID_COULEUR`) REFERENCES `couleur` (`ID_COULEUR`),
  ADD CONSTRAINT `Voiture_CATEGORIE2_FK` FOREIGN KEY (`ID_CATEGORIE`) REFERENCES `categorie` (`ID_CATEGORIE`),
  ADD CONSTRAINT `Voiture_ANNEE_FABRICATION3_FK` FOREIGN KEY (`ID_ANNEE_FABRICATION`) REFERENCES `annee_fabrication` (`ID_ANNEE_FABRICATION`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
